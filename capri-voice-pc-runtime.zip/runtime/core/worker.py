"""JSONL child process. Stdout is reserved for the protocol."""
import json
import os
from pathlib import Path
import sys
from threading import Thread
from time import perf_counter, sleep
import traceback

from finish import encode80, finish, segments
from engine import Engine, ROOT

protocol=sys.stdout
sys.stdout=sys.stderr
sys.path.insert(0,str(ROOT/'sdk'))


def send(payload):
    print(json.dumps(payload,ensure_ascii=False),file=protocol,flush=True)


def run():
    import numpy as np
    import psutil
    import soundfile as sf
    parent=int(os.environ.get('CAPRI_PARENT_PID',os.getppid()))
    def parent_alive():
        while psutil.pid_exists(parent):
            sleep(1)
        os._exit(71)
    Thread(target=parent_alive,daemon=True).start()
    model=Engine(*sys.argv[1:4])
    send({'ready':True})
    for line in sys.stdin:
        try:
            request=json.loads(line)
            begun=perf_counter()
            passages=segments(request['text'])
            pieces=[]
            first=None
            measurements=[]
            rate=None
            for passage in passages:
                audio,sr,metrics=model.synthesize(passage,request['seed'],request.get('exaggeration'))
                if rate is not None and rate!=sr:
                    raise RuntimeError('La frecuencia cambió entre segmentos')
                rate=sr
                if pieces:
                    pieces.append(np.zeros(round(rate*.075),dtype=np.float32))
                pieces.append(audio)
                measurements.append(metrics)
                if first is None:
                    first=perf_counter()-begun
                send({'progress':len(measurements),'total':len(passages),'first_segment_s':first})
            samples=np.concatenate(pieces)
            output=Path(request['output'])
            rendered,fx=finish(samples,rate,model.language,request.get('preset'))
            sf.write(output.with_suffix('.dry.wav'),samples,rate,subtype='PCM_16')
            sf.write(output,rendered,rate,subtype='PCM_24' if fx['state']=='processed' else 'PCM_16')
            encode80(output,output.with_suffix('.opus'))
            measure=measurements[0].copy()
            seconds=perf_counter()-begun
            duration=len(samples)/rate
            measure.update(processing=fx,segments=len(passages),first_segment_s=first,rtf=seconds/duration,
                           duration_s=duration,generation_s=seconds,
                           ram_peak_bytes=max(m['ram_peak_bytes'] for m in measurements),
                           vram_allocated_bytes=max((m['vram_allocated_bytes'] or 0 for m in measurements),default=0))
            send({'metrics':measure})
        except Exception as error:
            traceback.print_exc(file=sys.stderr)
            send({'error':str(error)[:500]})


if __name__=='__main__':
    try:
        run()
    except Exception as error:
        traceback.print_exc(file=sys.stderr)
        send({'error':str(error)[:500]})
        sys.exit(1)
