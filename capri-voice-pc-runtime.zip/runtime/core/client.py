"""Thin standard-library client for the V8 local CapriVoiceManager contract."""
import json
from urllib.parse import urlsplit
from urllib.request import Request,urlopen


class CapriVoiceManager:
    def __init__(self,ready_file,language='es-MX'):
        with open(ready_file,encoding='utf8') as f:
            session=json.load(f)
        url=urlsplit(session['url'])
        if url.scheme!='http' or url.hostname!='127.0.0.1' or not url.port or url.username or url.path!='/':
            raise ValueError('Se requiere una sesión local de Capri')
        self.base=session['url']+'api/'
        self.token=session['token']
        self.setLanguage(language)
        self.setQualityMode('automatic')

    def request(self,route,payload=None):
        request=Request(self.base+route,json.dumps(payload).encode() if payload is not None else None,
                        {'Content-Type':'application/json','X-Capri-Token':self.token})
        with urlopen(request,timeout=15) as response:
            return json.load(response)

    def initialize(self):
        return self.request(self.language)

    def listEngines(self):
        return self.initialize()['engines']

    def listProfiles(self):
        return self.initialize()['profiles']

    def detectHardware(self):
        return self.initialize()['hardware']

    def recommendEngine(self):
        return self.request('recommend',self.selection)

    def selectEngine(self,engine,profile):
        proposed={**self.selection,'mode':'manual','engine':engine,'profile':profile}
        info=self.request('select',proposed)
        self.selection=proposed
        return info

    def selectProfile(self,profile):
        match=next((p for p in self.listProfiles() if p['id']==profile),None)
        if match is None:
            raise ValueError('Perfil no instalado para el idioma seleccionado')
        return self.selectEngine(match['engine'],profile)

    def setLanguage(self,locale):
        if locale not in ('es-MX','en-US'):
            raise ValueError('Idioma no disponible')
        self.language=locale
        self.selection={'language':locale,'mode':'automatic'}

    def setQualityMode(self,mode):
        if mode not in ('automatic','light','balanced','fidelity','manual'):
            raise ValueError('Modo no disponible')
        if mode=='manual' and 'engine' not in self.selection:
            raise ValueError('Selecciona primero el motor y perfil del modo manual')
        self.selection['mode']=mode
        if mode!='manual':
            self.selection={k:v for k,v in self.selection.items() if k not in ('engine','profile','device')}

    def speak(self,text,**request):
        return self.request('synthesize',{**self.selection,'texts':[text],**request})

    def status(self,request_id):
        if len(request_id)!=32 or any(c not in '0123456789abcdef' for c in request_id):
            raise ValueError('ID inválido')
        return self.request('jobs/'+request_id)

    def stop(self,request_id):
        return self.request('cancel',{'id':request_id})

    def unload(self):
        return self.request('unload',{})

    def getMetrics(self):
        return self.request('metrics')
