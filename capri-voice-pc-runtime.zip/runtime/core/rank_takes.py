"""Rank independently generated takes of identical text, with no pitch or tempo edits."""
from argparse import ArgumentParser
import os
from pathlib import Path

from batch import intact, save
from engine import read

def rank(row):
    measures=row['scores']
    similarity=measures.get('speaker_heldout')
    return (row['status']!='technical-pass',len(row['technical_flags']),measures['wer'],
            -(similarity if similarity is not None else -1),measures['cut_edge'])

def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('manifests',nargs='+',type=Path)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    grouped={}
    for manifest in args.manifests:
        try:
            display=os.path.relpath(manifest.resolve(),args.out.parent.resolve()).replace(os.sep,'/')
        except ValueError:
            display=str(manifest.resolve())
        for row in read(manifest)['clips']:
            if not intact(row,manifest.parent):
                raise ValueError(f'Archivos modificados en {manifest}')
            entry=row['entry']
            key=(entry['id'],entry['language'],entry['text'],row['profile'])
            grouped.setdefault(key,[]).append((row,display))
    output=[]
    for key, versions in grouped.items():
        candidates=sorted(versions,key=lambda pair:rank(pair[0]))
        row,path=candidates[0]
        output.append(dict(id=key[0],language=key[1],text=key[2],profile=key[3],
                           winner_manifest=path,seed=row['seed'],status=row['status'],
                           alternatives=[dict(manifest=where,seed=what['seed'],status=what['status'])
                                         for what,where in candidates[1:]]))
    save(args.out,output)

if __name__=='__main__':
    main()
