"""Verify and apply the byte-frozen V7.2 DSP. Always keep the input master."""
from functools import lru_cache
import importlib.util
import os
from pathlib import Path
import re
import subprocess

from engine import ROOT, asset, read, resource

FX=ROOT/'voice-fx/v7.2'
DSP_ID='capri-cyber-voice-fx-7.2'


@lru_cache(maxsize=1)
def bindings():
    locks=read(ROOT/'PROFILE_LOCK.json')
    for name,checksum in locks.items():
        asset(ROOT/name,checksum)
    path=FX/'src/batch.py'
    spec=importlib.util.spec_from_file_location('capri_fx_v72_batch',path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    lib=module.load_fx(FX/'bin/windows-x64/CapriCyberVoiceFX.dll')
    return module,lib


def finish(pcm,rate,locale,preset=None):
    import numpy as np
    x=np.asarray(pcm,dtype=np.float32).reshape(-1,1)
    choice=preset or ('SIGNATURE' if locale=='es-MX' else 'OFF')
    if choice not in ('OFF','LIGHT','SIGNATURE') or (locale!='es-MX' and choice!='OFF'):
        raise ValueError('Preset de voz no aprobado para este perfil')
    if not len(x) or not np.isfinite(x).all() or np.max(np.abs(x))>=1:
        raise ValueError('PCM vacío, no finito o a escala completa')
    if choice=='OFF':
        return x,dict(version=None,preset='OFF',state='clean',gain_db=0.0)
    fx,lib=bindings()
    config=fx.get_presets()['presets'][choice]
    out,gain=fx.match_rms(x,fx.process(lib,x,rate,**config))
    if out.shape!=x.shape or not np.isfinite(out).all():
        raise RuntimeError('DSP produjo PCM incompatible')
    return out,dict(version=DSP_ID,preset=choice,state='processed',gain_db=gain,**config)


def encode80(wav,opus):
    args=[str(resource('ffmpeg')),'-nostdin','-v','error','-xerror']
    tmp=opus.with_suffix('.tmp.opus')
    subprocess.run(args+['-y','-i',str(wav),'-c:a','libopus','-b:a','80k','-vbr','on',str(tmp)],check=True)
    subprocess.run(args+['-i',str(tmp),'-f','null','-'],check=True)
    os.replace(tmp,opus)


def segments(text,max_chars=390):
    """Prefer sentence boundaries. Hard-wrap overlong sentences at word boundaries."""
    chunks=[]
    current=''
    for sentence in re.split(r'(?<=[.!?…])\s+|\n+',text.strip()):
        if not sentence:
            continue
        while len(sentence)>max_chars:
            limit=sentence.rfind(' ',0,max_chars+1)
            if limit<1:
                raise ValueError('Hay una palabra demasiado larga para el motor')
            if current:
                chunks.append(current)
                current=''
            chunks.append(sentence[:limit])
            sentence=sentence[limit+1:].lstrip()
        if len(current)+len(sentence)+1>max_chars:
            chunks.append(current)
            current=''
        current=(current+' '+sentence).strip()
    if current:
        chunks.append(current)
    return chunks
