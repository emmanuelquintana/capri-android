"""Measure speaker proxies, pitch contours, intensity and pauses on local WAVs."""
import argparse
import json
from math import gcd
from pathlib import Path
from statistics import mean

import librosa
import numpy as np
from scipy.signal import resample_poly
import sherpa_onnx as sherpa
import soundfile as sf


def db(array):
    return float(20*np.log10(max(1e-8,np.sqrt(np.mean(np.square(array))))))


def bands(mask, hop, rate):
    edges=np.flatnonzero(np.diff(np.r_[False,mask,False]))
    return [(a*hop/rate,b*hop/rate) for a,b in edges.reshape(-1,2)]


def report(path, probes, extractor, transcript):
    sound,src=sf.read(path,dtype='float32',always_2d=True)
    rate=16000
    ratio=gcd(src,rate)
    samples=resample_poly(sound.mean(axis=1),rate//ratio,src//ratio)
    hop=160
    frames=1024
    f0,voiced,_=librosa.pyin(samples,sr=rate,fmin=65,fmax=600,frame_length=frames,hop_length=hop)
    rms=librosa.feature.rms(y=samples,frame_length=frames,hop_length=hop)[0]
    rms_db=20*np.log10(np.maximum(1e-8,rms))
    actual=f0[np.isfinite(f0)]
    pct=lambda x: np.percentile(x,[10,50,90]).round(2).tolist() if len(x) else None
    timings=transcript.get('vad_seconds',[])
    pauses=[[round(a[1],3),round(b[0],3)] for a,b in zip(timings,timings[1:]) if b[0]-a[1]>=.12]
    if not timings:
        pauses=[list(pair) for pair in bands(rms_db<max(-65,float(np.max(rms_db))-35),hop,rate)
                if pair[0]>.15 and pair[1]<len(sound)/src-.15 and pair[1]-pair[0]>=.12]
    segments=[]
    for segment in transcript.get('segments',[]):
        for start,end,word,probability in segment.get('words',[]):
            low,high=round(start*rate/hop),round(end*rate/hop)
            if high<=low:
                continue
            tone=f0[low:high]
            strength=rms_db[low:high]
            segments.append({'word':word.strip(),'seconds':[start,end],'asr_probability':probability,
                             'f0_hz':pct(tone[np.isfinite(tone)]),
                             'rms_dbfs_median':round(float(np.median(strength)),2) if len(strength) else None})
    vector=embedding(extractor,samples)
    values={key:round(float(np.dot(vector,probe)),4) for key,probe in probes.items()} if vector is not None else {}
    return {'f0_hz_p10_p50_p90':pct(actual),'voiced_fraction':round(float(np.mean(voiced)),4),
            'rms_dbfs':round(db(sound),2),'audible_rms_dbfs_p10_p50_p90':pct(rms_db[rms_db>max(-65,float(np.max(rms_db))-35)]),
            'internal_pause_windows':pauses,'pause_seconds':round(sum(b-a for a,b in pauses),3),
            'duration_s':len(sound)/src,'sample_rate':src,'full_scale_samples':int((np.abs(sound)>=1).sum()),
            'f0_contour_10ms':[round(float(p),1) if np.isfinite(p) else None for p in f0],
            'rms_contour_dbfs_10ms':rms_db.round(1).tolist(),
            'words':segments,'speaker_scores':values,'speaker_heldout':mean(values.values()) if values else None},vector


def embedding(extractor,samples):
    stream=extractor.create_stream()
    stream.accept_waveform(sample_rate=16000,waveform=samples)
    stream.input_finished()
    if not extractor.is_ready(stream):
        return None
    result=np.asarray(extractor.compute(stream))
    return result/np.linalg.norm(result)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--asr',type=Path,action='append',required=True)
    parser.add_argument('--model',required=True)
    parser.add_argument('--probe',type=Path,action='append',required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('paths',type=Path,nargs='+')
    args=parser.parse_args()
    extractor=sherpa.SpeakerEmbeddingExtractor(sherpa.SpeakerEmbeddingExtractorConfig(model=args.model,num_threads=2))
    probes={}
    for path in args.probe:
        source,rate=sf.read(path,dtype='float32',always_2d=True)
        ratio=gcd(rate,16000)
        probes[path.stem]=embedding(extractor,resample_poly(source.mean(axis=1),16000//ratio,rate//ratio))
    assert all(v is not None for v in probes.values())
    asr={Path(row['file']).resolve():row for p in args.asr for row in json.loads(p.read_text(encoding='utf-8')) if 'file' in row}
    results={}
    groups={}
    for path in args.paths:
        result,vector=report(path,probes,extractor,asr.get(path.resolve(),{}))
        results[str(path.resolve())]=result
        if 'tomas' in path.parts and vector is not None:
            groups.setdefault(path.parent.name,[]).append(vector)
        print(path.name,path.parent.name,result['f0_hz_p10_p50_p90'],flush=True)
    stability={name:float(mean(float(a@b) for i,a in enumerate(vectors) for b in vectors[i+1:]))
               for name,vectors in groups.items() if len(vectors)>1}
    with args.out.open('x',encoding='utf-8') as stream:
        json.dump({'files':results,'speaker_intra_condition':stability},stream,ensure_ascii=False)
