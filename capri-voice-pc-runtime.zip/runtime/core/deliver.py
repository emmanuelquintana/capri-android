"""Verify the private review and make a single portable archive."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote
from wave import open as wave_open
from zipfile import ZipFile

from batch import intact
from engine import ROOT, read, sha
from package import collect, zip_paths


class MediaLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths=[]
    def handle_starttag(self,tag,attributes):
        if tag=='audio':
            self.paths.append(unquote(dict(attributes)['src']))


def build():
    languages=('es-MX','en-US')
    for language in languages:
        folder=ROOT/'voice-library'/language
        manifest=read(folder/'manifest.json')
        assert len(manifest['clips'])==20
        for item in manifest['clips']:
            assert intact(item,folder)
            with wave_open(str(folder/item['formats']['wav']['asset']),'rb') as pcm:
                assert pcm.getnchannels()==1 and pcm.getsampwidth()==2 and pcm.getframerate()==24000
                assert abs(pcm.getnframes()/pcm.getframerate()-item['duration_s'])<0.001

    links=MediaLinks()
    links.feed((ROOT/'ESCUCHA_PILOTO.html').read_text(encoding='utf8'))
    assert len(links.paths)>=40
    for filename in links.paths:
        assert (ROOT/filename).is_file(),filename
    release=ROOT/'release-assets'
    for line in (release/'checksums.sha256').read_text(encoding='ascii').splitlines():
        digest,name=line.split('  ',1)
        assert sha(release/name)==digest,name

    release_names=[entry['local'] for entry in read(release/'catalog.json')['packages']]
    release_names+=['capri-tauri-example.exe','catalog.json','checksums.sha256','INTEGRATION.md']
    patterns=['.gitignore','resources.json','CLAUDE_START_HERE.md','ESCUCHA_PILOTO.html','core/**/*.py','core/v6/*.wav',
              'catalogs/*','profiles/**/*','voice-library/**/*','sdk/capri_voice/*.py','sdk/capri_voice/*.json',
              'sdk/tauri/example/**/*','sdk/examples/*','studio/*.html','studio/*.css','studio/*.js',
              'studio/*.rs','studio/*.exe','studio/*.cmd','tests/*.py','tests/*.cjs',
              'reports/*.md','reports/*.log','reports/*.json','reports/english-benchmark/**/*',
              'reports/retakes-*/**/*','reports/studio-*.png']
    paths=[(p,arc) for p,arc in collect(patterns) if not p.name.endswith('.local.json') and
           not p.name.startswith(('browser-service','final-service'))]
    paths.extend((release/name,Path('release-assets')/name) for name in release_names)
    archive=ROOT.parent/'CAPRI_VOICE_V7_PRIVATE.zip'
    zipped=zip_paths(archive,[(path,Path(ROOT.name)/arc) for path,arc in paths])
    with ZipFile(zipped) as result:
        all_files=set(result.namelist())
        assert len(all_files)==len(result.namelist())
        assert {f'{ROOT.name}/{p}' for p in links.paths}<=all_files
    print(archive)
    print(f'{len(paths)} archivos | {len(set(links.paths))} WAV enlazados | {archive.stat().st_size} bytes')
    print(sha(archive))


if __name__=='__main__':
    build()
