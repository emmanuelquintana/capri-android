"""Use equal texts, transcript and speaker checks to nominate one English pilot profile."""
from statistics import mean, median
from engine import ROOT, read, sha
from batch import save

root=ROOT/'reports/english-benchmark'
table=[]
for engine in ('turbo','multilingual','qwen06','qwen17'):
    path=root/engine/'manifest.json'
    rows=read(path)['clips'] if path.is_file() else []
    heldout=[r['scores']['speaker_heldout'] for r in rows if r['scores']['speaker_heldout'] is not None]
    stability=[r['scores']['speaker_median_other'] for r in rows if 'speaker_median_other' in r['scores']]
    table.append(dict(engine=engine,clips=len(rows),technical_pass=sum(r['status']=='technical-pass' for r in rows),
                      mean_wer=mean([r['scores']['wer'] for r in rows]) if rows else None,
                      heldout_mean=mean(heldout) if heldout else None,heldout_min=min(heldout) if heldout else None,
                      stability=median(stability) if stability else None,
                      rtf=median([r['rtf'] for r in rows]) if rows else None,
                      holdout_exposure=engine=='turbo',device=rows[0]['device'] if rows else None))
eligible=[r for r in table if r['clips']==3 and r['technical_pass']==3 and r['stability'] is not None and
          r['stability']>=.5 and r['heldout_min']>=.3 and not r['holdout_exposure']]
winner=max(eligible,key=lambda r:(r['heldout_mean']*.55+r['stability']*.45,-r['mean_wer'],-r['rtf']),default=None)
save(ROOT/'reports/english-selection.json',dict(
    criteria='3/3 technical-pass; within-profile median ≥0.5; heldout minimum ≥0.30; exclude exposed holdout; rank 55% reference and 45% consistency.',
    limitations='One source recording, separate time windows. These proxies cannot assess naturalness, acting or cross-language identity.',
    comparison=table,winner=winner))
if winner:
    engine=winner['engine']
    records=read(root/engine/'manifest.json')['clips']
    source=read(ROOT/'profiles/en-US-source/conditioning.json')
    save(ROOT/'profiles/en-US-best/profile.json',dict(id='en-US-best',version='7.0.0-pilot',locale='en-US',
        runtime_profile=f'en-US-{engine}',engine=engine,device=winner['device'],scope='private-pilot',
        status='technical shortlist; perceptual review pending',revision=records[0]['revision'],
        parameters=records[0]['parameters'],seed=records[0]['seed'],conditioning=source,
        comparison='reports/english-selection.json',holdout_sha256=sha(ROOT/'profiles/en-US-source/holdout.wav')))
    print(engine,winner['device'])
