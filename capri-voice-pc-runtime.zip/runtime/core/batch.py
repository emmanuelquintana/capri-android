"""Offline generation and QA. Each existing, byte-verified clip can be resumed."""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import unicodedata

from engine import Engine, REPO, ROOT, read, resource, sha


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    os.replace(temporary, path)


def pilot(language):
    for line in (ROOT/'catalogs/pilot.tsv').read_text(encoding='utf8').splitlines():
        event, emotion, category, es, en = line.split('\t')
        yield dict(id=f'{category}.{event}.{emotion}', event=event, emotion=emotion, category=category,
                   text=es if language=='es-MX' else en, language=language)


def words(text):
    return re.findall(r"[^\W_]+(?:'[^\W_]+)?", unicodedata.normalize('NFKC', text).lower().replace('’',"'"))


def wer(text, transcript):
    a,b=words(text),words(transcript)
    row=list(range(len(b)+1))
    for i,word in enumerate(a,1):
        current=[i]
        for j,target in enumerate(b,1):
            current.append(min(row[j]+1,current[-1]+1,row[j-1]+(word!=target)))
        row=current
    return row[-1]/max(1,len(a))


def repeated(text, transcript):
    def pairs(value):
        tokens=words(value)
        return Counter(zip(tokens,tokens[1:]))
    reference,heard=pairs(text),pairs(transcript)
    return any(count>1 and count>reference[pair] for pair,count in heard.items())


def encode(wav, opus):
    cmd=[str(resource('ffmpeg')),'-nostdin','-hide_banner','-v','error','-xerror']
    tmp=opus.with_name(opus.stem+'.tmp.opus')
    subprocess.run(cmd+['-y','-i',str(wav),'-c:a','libopus','-b:a','48k','-vbr','on',str(tmp)],check=True)
    subprocess.run(cmd+['-i',str(tmp),'-f','null','-'],check=True)
    os.replace(tmp,opus)


def evaluate_file(wav, text, language, asr, extractor, probes):
    from measure import report
    import soundfile as sf
    from scipy.signal import resample_poly
    from math import gcd
    samples,rate=sf.read(wav,dtype='float32')
    ratio=gcd(rate,16000)
    decoded=resample_poly(samples,16000//ratio,rate//ratio)
    segments,_=asr.transcribe(decoded,language={'es-MX':'es','en-US':'en'}[language],beam_size=5,
                              condition_on_previous_text=False,word_timestamps=True)
    timing=[{'start':s.start,'end':s.end,'words':[(w.start,w.end,w.word,w.probability) for w in s.words],
             'text':s.text} for s in segments]
    transcript=' '.join(s['text'].strip() for s in timing)
    scores,vector=report(wav,probes,extractor,{'segments':timing})
    return {'asr_text':transcript,'wer':wer(text,transcript),
            'word_rate':len(words(text))/scores['duration_s'],
            'cut_edge':max(scores['rms_contour_dbfs_10ms'][-3:])>-27,
            **scores}, vector


def qa_resources(language):
    from faster_whisper import WhisperModel
    import sherpa_onnx as sherpa
    import soundfile as sf
    from scipy.signal import resample_poly
    from math import gcd
    v6=REPO/'CAPRI_VOICE_V6_AUTONOMOUS'
    evaluator=v6/'tools'
    if not evaluator.exists():
        evaluator=ROOT/'core/v6'
    sys.path.insert(0,str(evaluator))
    from measure import embedding
    asr=WhisperModel(str(resource('asr')),device='cpu',compute_type='int8',cpu_threads=3,local_files_only=True)
    extractor=sherpa.SpeakerEmbeddingExtractor(sherpa.SpeakerEmbeddingExtractorConfig(model=str(resource('titanet')),num_threads=2))
    paths=([v6/'references'/f'probe-{i}-demucs.wav' for i in (1,2)] if language=='es-MX'
           else [ROOT/'profiles/en-US-source/holdout.wav'])
    if language=='es-MX' and not paths[0].exists():
        paths=[ROOT/'core/v6'/p.name for p in paths]
    probes={}
    for p in paths:
        sound,rate=sf.read(p,dtype='float32',always_2d=True)
        ratio=gcd(rate,16000)
        probes[p.stem]=embedding(extractor,resample_poly(sound.mean(axis=1),16000//ratio,rate//ratio))
    assert all(v is not None for v in probes.values())
    return asr,extractor,probes


def intact(item, folder):
    return all((folder/info['asset']).is_file() and sha(folder/info['asset'])==info['sha256']
               for info in item['formats'].values())


def run(entries, engine_name, language, device, folder, seed=937, stage='all', exaggeration=None):
    import numpy as np
    import soundfile as sf

    folder.mkdir(parents=True,exist_ok=True)
    records=[]
    model=None
    qa=None
    vectors={}
    for entry in entries:
        stem=entry['id']
        if not re.fullmatch(r'[a-z][a-z0-9._-]{0,95}',stem):
            raise ValueError(f'Identificador inválido: {stem}')
        record=folder/f'{stem}.json'
        raw_record=folder/f'{stem}.raw.json'
        wav,opus=(folder/f'{stem}.{suffix}' for suffix in ('wav','opus'))
        key=dict(entry=entry,engine=engine_name,device=device,requested_seed=seed)
        if exaggeration is not None:
            key['requested_exaggeration']=exaggeration
        if record.exists():
            saved=read(record)
            if intact(saved,folder) and all(saved.get(k)==v for k,v in key.items()):
                records.append(saved)
                if saved['speaker_vector']:
                    vectors[stem]=np.asarray(saved['speaker_vector'])
                continue
        raw=read(raw_record) if raw_record.is_file() else {}
        if not (raw and raw['key']==key and wav.is_file() and sha(wav)==raw['wav_sha256']):
            if stage=='qa':
                print('No hay WAV verificado para',stem,flush=True)
                continue
            if model is None:
                model=Engine(engine_name,language,device)
            samples,rate,meta=model.synthesize(entry['text'],seed,exaggeration)
            peak=float(np.max(np.abs(samples)))
            tmp=wav.with_name(wav.stem+'.tmp.wav')
            sf.write(tmp,samples,rate,subtype='PCM_16')
            os.replace(tmp,wav)
            raw=dict(key=key,peak=peak,meta=meta,wav_sha256=sha(wav))
            save(raw_record,raw)
            print('PCM',language,engine_name,stem,flush=True)
        if stage=='generate':
            continue
        if qa is None:
            qa=qa_resources(language)
        peak,meta=raw['peak'],raw['meta']
        scores,vector=evaluate_file(wav,entry['text'],language,*qa)
        scores['source_peak']=peak
        issues=[]
        if scores['rms_dbfs'] < -45 or scores['voiced_fraction'] < .10:
            issues.append('voz insuficiente')
        if peak>=1:
            issues.append('clipping de origen')
        if scores['wer']>.15:
            issues.append('transcripción divergente')
        if scores['cut_edge'] or not 1.1<=scores['word_rate']<=5.5:
            issues.append('borde o velocidad atípicos')
        if scores['speaker_heldout'] is None:
            issues.append('sin medición de hablante')
        encode(wav,opus)
        formats={p.suffix[1:]:dict(asset=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in (wav,opus)}
        saved=dict(entry=entry,profile='es-MX-best' if language=='es-MX' else f'en-US-{engine_name}',
                   version='7.0.0-pilot',scope='private-pilot',authorization='reports/AUTHORIZATION.md',
                   human='pendiente',emotion_control='etiqueta editorial; actuación no garantizada',
                   formats=formats,flags=issues,requested_seed=seed,scores=scores,
                   speaker_vector=vector.tolist() if vector is not None else None,**meta)
        if exaggeration is not None:
            saved['requested_exaggeration']=exaggeration
        if vector is not None:
            vectors[stem]=vector
        save(record,saved)
        records.append(saved)
        print(language,engine_name,stem,round(scores['wer'],3),scores['speaker_heldout'],issues,flush=True)
    if stage=='generate':
        return
    seen=set()
    for item in records:
        stem=item['entry']['id']
        marks=list(item['flags'])
        digest=item['formats']['wav']['sha256']
        if digest in seen:
            marks.append('WAV duplicado')
        seen.add(digest)
        if repeated(item['entry']['text'],item['scores']['asr_text']):
            marks.append('repetición de palabras detectada')
        if stem in vectors and len(vectors)>2:
            others=[float(vectors[stem]@v) for key,v in vectors.items() if key!=stem]
            item['scores']['speaker_median_other']=float(np.median(others))
            if item['scores']['speaker_median_other']<.38:
                marks.append('consistencia vocal baja')
        item['technical_flags']=marks
        item['status']='review' if marks else 'technical-pass'
    save(folder/'manifest.json',dict(schema=1,scope='private-pilot',language=language,clips=records))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['pilot','benchmark','catalog'])
    p.add_argument('language',choices=['es-MX','en-US'])
    p.add_argument('engine',choices=['qwen06','qwen17','turbo','multilingual'])
    p.add_argument('device',choices=['cpu','cuda:0'])
    p.add_argument('--seed',type=int,default=937)
    p.add_argument('--limit',type=int,default=20)
    p.add_argument('--offset',type=int,default=0)
    p.add_argument('--out',type=Path)
    p.add_argument('--ids',nargs='+')
    p.add_argument('--exaggeration',type=float)
    p.add_argument('--stage',choices=['all','generate','qa'],default='all')
    p.add_argument('--production-approval',type=Path)
    args=p.parse_args()
    if (args.seed!=937 or args.exaggeration is not None or args.ids) and args.out is None:
        p.error('Las variantes requieren una carpeta explícita para conservar el piloto original')
    entries=list(pilot(args.language))
    if args.mode=='benchmark':
        entries=[entries[i] for i in (2,9,13)]
    elif args.mode=='catalog':
        if args.production_approval is None or args.out is None:
            p.error('El catálogo completo requiere autorización registrada, aprobación auditiva y un destino separado')
        approval=read(args.production_approval)
        selected=(read(ROOT/'profiles/en-US-best/profile.json')['engine'] if args.language=='en-US' else 'qwen06')
        if (approval.get('locale')!=args.language or approval.get('engine')!=args.engine or args.engine!=selected
            or approval.get('audition_approved') is not True or not approval.get('distribution_permission')):
            p.error('La constancia no valida este idioma y motor para producción')
        entries=[e for e in read(ROOT/'catalogs/catalog.json')['entries'] if e['language']==args.language]
    if args.ids:
        entries=[e for e in entries if e['id'] in set(args.ids)]
        if {e['id'] for e in entries}!=set(args.ids):
            p.error('Uno o más identificadores no existen en el catálogo seleccionado')
    entries=entries[args.offset:args.offset+args.limit]
    if not entries:
        p.error('La selección no contiene entradas')
    folder=args.out or (ROOT/'voice-library'/args.language if args.mode=='pilot' else ROOT/'reports/english-benchmark'/args.engine)
    run(entries,args.engine,args.language,args.device,folder,args.seed,args.stage,args.exaggeration)


if __name__=='__main__':
    sys.path.insert(0,str(ROOT/'sdk'))
    main()
