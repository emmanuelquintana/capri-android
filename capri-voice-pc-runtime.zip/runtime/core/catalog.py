"""Build the original bilingual text catalog."""
from batch import pilot, save
from engine import ROOT


def entries():
    for language in ('es-MX','en-US'):
        yield from ({**item,'animationHint':None} for item in pilot(language))
    for section in (ROOT/'catalogs/expanded.txt').read_text(encoding='utf8').strip().split('\n\n'):
        header,*lines=section.splitlines()
        category,emotion,gesture=header.split()
        for i,line in enumerate(lines,1):
            es,en=line.split('|')
            for language,text in (('es-MX',es),('en-US',en)):
                yield dict(id=f'{category}.original-{i:02}.{emotion}',event=f'{category}.original-{i:02}',
                           category=category,emotion=emotion,animationHint=gesture,text=text,language=language)

if __name__=='__main__':
    rows=list(entries())
    for lang in ('es-MX','en-US'):
        col=[r for r in rows if r['language']==lang]
        assert len({r['text'] for r in col})==len({r['id'] for r in col})==len(col)>=200
    save(ROOT/'catalogs/catalog.json',dict(schema=1,version='7.0.0',entries=rows))
