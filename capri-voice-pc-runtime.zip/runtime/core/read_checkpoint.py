"""Read a local safetensors checkpoint without Windows copy-on-write mmap."""
import json
import math
import mmap
from pathlib import Path

import torch


class TensorSlice:
    def __init__(self, storage, entry):
        self.storage = storage
        self.entry = entry

    def get_shape(self):
        return self.entry['shape']

    def get_dtype(self):
        return self.entry['dtype']

    def __getitem__(self, index):
        dtype = self.storage.dtypes[self.get_dtype()]
        begin, end = self.entry['data_offsets']
        assert begin >= 0 and begin <= end <= self.storage.data_length
        assert end - begin == math.prod(self.get_shape()) * dtype.itemsize
        if begin == end:
            return torch.empty(self.get_shape(), dtype=dtype, device=self.storage.device)[index]
        # Inference leaves CPU weights intact, so they can stay backed by the original file.
        tensor = torch.frombuffer(self.storage.mapping, dtype=dtype,
                                  count=math.prod(self.get_shape()),
                                  offset=self.storage.header_end + begin).reshape(self.get_shape())
        return tensor[index].to(self.storage.device)


class ReadOnlyCheckpoint:
    dtypes = {'BF16': torch.bfloat16, 'F16': torch.float16, 'F32': torch.float32,
              'F64': torch.float64, 'I64': torch.int64, 'I32': torch.int32,
              'I16': torch.int16, 'I8': torch.int8, 'U8': torch.uint8, 'BOOL': torch.bool}

    def __init__(self, filename, framework, device='cpu'):
        assert framework == 'pt'
        path = Path(filename)
        self.device = device
        self.file = path.open('rb')
        length = int.from_bytes(self.file.read(8), 'little')
        self.header_end = length + 8
        self.data_length = path.stat().st_size - self.header_end
        assert 0 < length <= 16_000_000 and self.data_length >= 0
        self.entries = json.loads(self.file.read(length))
        self.info = self.entries.pop('__metadata__', None)
        self.mapping = mmap.mmap(self.file.fileno(), 0, access=mmap.ACCESS_READ)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.file.close()

    def metadata(self):
        return self.info

    def keys(self):
        return sorted(self.entries)

    def get_slice(self, key):
        return TensorSlice(self, self.entries[key])

    def get_tensor(self, key):
        return self.get_slice(key)[...]

    def get_tensors(self):
        return {name: self.get_tensor(name) for name in self.keys()}
