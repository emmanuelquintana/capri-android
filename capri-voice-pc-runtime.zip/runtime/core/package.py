"""Build private clip packs and the offline review from verified manifests."""
from collections import Counter
from html import escape
import json
from pathlib import Path
from statistics import median, mean
import sys
from urllib.parse import quote
from zipfile import ZIP_DEFLATED, ZipFile

from batch import intact, save
from engine import REPO, ROOT, read, resource, sha

sys.path.insert(0,str(ROOT/'sdk'))
from capri_voice.clips import decode_manifest

RELEASE=ROOT/'release-assets'


def zip_paths(target, files, extra=()):
    temp=target.with_suffix('.tmp.zip')
    with ZipFile(temp,'w',compression=ZIP_DEFLATED,compresslevel=4) as zipped:
        for file,arc in files:
            zipped.write(file,str(arc).replace('\\','/'))
        for arc,data in extra:
            zipped.writestr(arc,data)
    with ZipFile(temp) as zipped:
        assert zipped.testzip() is None
    temp.replace(target)
    return target


def clip_pack(library, manifest):
    language=manifest['language']
    name=f'capri-clips-{language}'
    rows=[]
    files=[]
    retake_path=ROOT/'reports/retakes-es/manifest.json'
    retakes={}
    if language=='es-MX' and retake_path.is_file():
        retakes={row['entry']['id']:row for row in read(retake_path)['clips'] if row['status']=='technical-pass'}
    eligible=[row['speaker_vector'] for row in manifest['clips']
              if row['status']=='technical-pass' and row['speaker_vector']]
    for record in manifest['clips']:
        assert intact(record,library)
        source=library
        if record['status']!='technical-pass':
            alternate=retakes.get(record['entry']['id'])
            if (not alternate or record['entry']!=alternate['entry'] or not alternate['speaker_vector']
                or not eligible or median(sum(a*b for a,b in zip(alternate['speaker_vector'],vector))
                                           for vector in eligible)<.38):
                continue
            record,source=alternate,retake_path.parent
            assert intact(record,source)
        entry=record['entry']
        info=record['formats']['opus']
        clip_path=f"{language}/{entry['category']}/{entry['id']}.opus"
        event=entry['id'].rsplit('.',1)[0]
        rows.append(dict(id=entry['id'],eventId=event,appEvent=entry['event'],language=language,
                         emotion=entry['emotion'],text=entry['text'],eventType=entry['category'],animationHint={
                            'greeting':'wave','goodbye':'wave','surprise':'blink','celebrate':'cheer','company':'sit'
                         }.get(entry['category'],''),
                         durationMs=round(record['duration_s']*1000),sha256=info['sha256'],asset=clip_path,
                         bytes=info['bytes'],format='opus',status=record['status'],human=record['human'],
                         profile=record['profile'],engine=record['engine'],seed=record['seed'],
                         authorization=record['authorization']))
        files.append((source/info['asset'],clip_path))
    meta=dict(schemaVersion=1,id=f'{name}-private-pilot',language=language,scope='private-pilot',
              version='7.0.0-pilot',clips=rows)
    decode_manifest(meta,allow_private=True)
    path=zip_paths(RELEASE/f'{name}.zip',files,[('manifest.json',json.dumps(meta,ensure_ascii=False,indent=2))])
    return path,dict(id=meta['id'],language=language,version=meta['version'],type='clip-pack',
                     scope='private-pilot',platforms=['Windows', 'Android SDK; decoding on device pending'],
                     license='Autorización privada declarada. Consultar reports/AUTHORIZATION.md.',
                     approval='technical only',count=len(rows),local=path.name)


def review(libraries):
    def card(row, folder=None):
        entry=row['entry']
        wav=row['formats']['wav']['asset']
        language=entry['language']
        path=quote(f'{folder or "voice-library/"+language}/{wav}')
        state='Pasa revisión automática' if row['status']=='technical-pass' else 'Requiere revisión'
        return (f'<li><p>{escape(entry["text"])}</p><small>{escape(entry["emotion"])} · {state} · {row["duration_s"]:.2f} s</small>'
                f'<audio controls preload="none" src="{path}" aria-label="{escape(entry["text"],quote=True)}"></audio></li>')
    pairs={}
    for lib in libraries:
        for row in lib['clips']:
            pairs.setdefault(row['entry']['id'],{})[lib['language']]=row
    comparisons=''.join(f'<li class="pair"><h2>{escape(key)}</h2><div class="columns">'
                        +''.join(f'<section lang="{lang}"><h3>{lang}</h3><ul>{card(rows[lang])}</ul></section>'
                                 for lang in ('es-MX','en-US') if lang in rows)
                        +'</div></li>' for key,rows in pairs.items())
    retakes=[]
    for locale,prefix in [('es-MX','retakes-es'),('en-US','retakes-en')]:
        manifest=ROOT/'reports'/prefix/'manifest.json'
        if manifest.is_file():
            for row in read(manifest)['clips']:
                key=row['entry']['id']
                param='semilla 1411' if locale=='es-MX' else 'exaggeration 0.8'
                retakes.append(f'<li class="pair"><h3>{escape(key)}</h3><div class="columns">'
                               f'<section><h4>Piloto</h4><ul>{card(pairs[key][locale])}</ul></section>'
                               f'<section><h4>Variante · {param}</h4><ul>{card(row,"reports/"+prefix)}</ul></section>'
                               '</div></li>')
    variants=('<h2>Variantes controladas</h2><ul>'+''.join(retakes)+'</ul>') if retakes else ''
    (ROOT/'ESCUCHA_PILOTO.html').write_text(
        '<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Capri Voice V7 · Piloto privado</title><style>body{margin:2rem auto;padding:0 1rem;max-width:65rem;'
        'background:#f6f7fa;color:#182035;font:16px/1.5 system-ui}.columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));'
        'gap:1rem}h2{font-size:1.15rem;margin-bottom:0}h3{font-size:1rem}ul{padding:0;list-style:none}'
        '.pair{border-top:1px solid #cdd5e2;margin:.9rem 0}section{min-width:0}audio{display:block;width:100%;margin:.5rem 0}'
        '@media(max-width:44rem){.columns{grid-template-columns:1fr}}</style>'
        '<main><h1>Capri Voice V7</h1><p>Piloto privado. Escucha la identidad y la pronunciación de cada idioma. '
        'Las intenciones son etiquetas del catálogo. La evaluación humana sigue pendiente.</p>'
        f'<ul>{comparisons}</ul>{variants}</main></html>',encoding='utf8')


def base_catalog():
    result=[]
    for key,model,license in [
        ('Qwen/Qwen3-TTS-12Hz-0.6B-Base','qwen06','Apache-2.0'),
        ('Qwen/Qwen3-TTS-12Hz-1.7B-Base','qwen17','Apache-2.0'),
        ('ResembleAI/chatterbox Multilingual T3 v2','multilingual','MIT')]:
        for item in read(ROOT/'reports/weight-locks.json')[key]:
            repo=key if model.startswith('qwen') else 'ResembleAI/chatterbox'
            revision=item['revision']
            if revision is None and item.get('matches_verified_qwen_17b_tokenizer'):
                repo='Qwen/Qwen3-TTS-12Hz-1.7B-Base'
                revision='fd4b254389122332181a7c3db7f27e918eec64e3'
            if revision is None:
                continue
            result.append(dict(engine=model,filename=item['file'],revision=item['revision'],
                               sha256=item['sha256'],bytes=item['size'],license=license,
                               url=f"https://huggingface.co/{repo}/resolve/{revision}/{item['file']}",
                               upstream_revision=revision,
                               scope='upstream-base-weight',not_a_complete_runtime=True,
                               hardware='PC x86_64; existing runtime required'))
    return result


def main():
    artifacts=[]
    manifests=[]
    for lang in ('es-MX','en-US'):
        lib=ROOT/'voice-library'/lang
        if (lib/'manifest.json').is_file():
            manifest=read(lib/'manifest.json')
            if manifest['clips']:
                manifests.append(manifest)
                if any(row['status']=='technical-pass' for row in manifest['clips']):
                    artifacts.append(clip_pack(lib,manifest))
    review(manifests)
    android=ROOT/'sdk/android'
    android_data=[(p,Path('android')/p.relative_to(android)) for p in sorted(android.rglob('*')) if p.is_file()
                  and not any(x in ('build','.gradle','.kotlin','local.properties') for x in p.relative_to(android).parts)]
    compile_artifacts=[(android/'qwen-voice/build/outputs/aar/qwen-voice-release.aar','capri-voice-android.aar'),
                       (android/'clip-demo/build/outputs/apk/debug/clip-demo-debug.apk','capri-private-clip-demo.apk')]
    if all(p.is_file() for p,_ in compile_artifacts):
        adapter=ROOT/'sdk/examples/EarsVoiceAdapter.kt'
        artifacts.append((zip_paths(RELEASE/'capri-voice-android-sdk.zip',android_data+compile_artifacts+
                                    [(adapter,'examples/EarsVoiceAdapter.kt')]),
                          dict(id='capri-voice-android-sdk',type='sdk',version='7.0.0-pilot',
                               scope='code-and-native-bridge',platforms=['Android API 31+','arm64-v8a','x86_64'],
                               local='capri-voice-android-sdk.zip')))
    desktop_patterns=['core/*.py','sdk/capri_voice/*.py','sdk/capri_voice/*.json','sdk/tauri/example/**/*','sdk/examples/*',
                      'tests/*.py','tests/*.cjs','resources.json','CLAUDE_START_HERE.md','catalogs/*',
                      'reports/weight-locks.json','reports/AUTHORIZATION.md']
    desktop=collect(desktop_patterns+['release-assets/capri-tauri-example.exe'])
    win=collect(['studio/index.html','studio/studio.css','studio/studio.js','studio/*.cmd','studio/*.exe','studio/*.rs'])
    profiles=collect(['profiles/**/*','reports/english-selection.json','core/v6/*','voice-library/*/manifest.json',
                      'voice-library/*/*.wav','voice-library/*/*.opus','ESCUCHA_PILOTO.html',
                      'reports/retakes-*/*.wav','reports/retakes-*/manifest.json','reports/VALIDACION.md'])
    for name,files,scope in [('capri-voice-desktop-sdk.zip',desktop,'code-and-runtime-contract'),
                             ('capri-voice-studio-windows-private.zip',desktop+win+profiles,'private-pilot')]:
        artifacts.append((zip_paths(RELEASE/name,files),dict(id=name.removesuffix('.zip'),type='desktop',
                          version='7.0.0-pilot',scope=scope,platforms=['Windows x86_64'],local=name)))
    entries=[{**meta,'bytes':p.stat().st_size,'sha256':sha(p)} for p,meta in artifacts]
    save(RELEASE/'catalog.json',dict(schema=1,version='7.0.0-pilot',packages=entries,optional_base_files=base_catalog()))
    known=[p for p,_ in artifacts]+[p for p in (RELEASE/'catalog.json',RELEASE/'capri-tauri-example.exe') if p.is_file()]
    (RELEASE/'checksums.sha256').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(known)),encoding='ascii')
    stats=[]
    for library in manifests:
        rows=library['clips']
        sims=[row['scores']['speaker_heldout'] for row in rows if row['scores']['speaker_heldout'] is not None]
        stats.append(dict(locale=library['language'],clips=len(rows),technical_states=dict(Counter(r['status'] for r in rows)),
                          mean_wer=mean(r['scores']['wer'] for r in rows),median_rtf=median(r['rtf'] for r in rows),
                          reference_score_mean=mean(sims) if sims else None,
                          wav_bytes=sum(r['formats']['wav']['bytes'] for r in rows),
                          opus_bytes=sum(r['formats']['opus']['bytes'] for r in rows),
                          duration_s=sum(r['duration_s'] for r in rows),
                          review=[r['entry']['id'] for r in rows if r['status']!='technical-pass']))
    save(ROOT/'reports/pilot-summary.json',stats)


def collect(patterns):
    paths={p for pattern in patterns for p in ROOT.glob(pattern) if p.is_file()
           and not any(part in ('target','__pycache__','data','gen') for part in p.relative_to(ROOT).parts)}
    return [(p,p.relative_to(ROOT)) for p in sorted(paths)]


if __name__=='__main__':
    main()
