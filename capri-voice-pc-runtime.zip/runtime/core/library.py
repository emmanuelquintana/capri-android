"""Private clip decks. This scope is excluded unless the caller opts in."""
from engine import ROOT, asset, read


class VoiceClipLibrary:
    def __init__(self, directory=ROOT/'voice-library', allow_private=False):
        self.root=directory
        self.allow_private=allow_private

    def listEvents(self,language):
        manifest=self.root/language/'manifest.json'
        if language not in ('es-MX','en-US') or not manifest.is_file():
            return []
        deck=read(manifest)
        return deck['clips'] if self.allow_private and deck['scope']=='private-pilot' else []

    def findClip(self,event,language,text,emotion,allowed_variants=()):
        rows=self.listEvents(language)
        for variant in (emotion,*allowed_variants):
            for row in rows:
                entry=row['entry']
                if (row['status']=='technical-pass' and entry['event']==event and
                    entry['emotion']==variant and entry['text']==text and entry['language']==language):
                    return row
        return None

    def preload(self,row,format='wav'):
        if format not in ('wav','opus'):
            raise ValueError('Formato no disponible')
        info=row['formats'][format]
        folder=(self.root/row['entry']['language']).resolve()
        path=(folder/info['asset']).resolve()
        if path.parent!=folder:
            raise ValueError('Ruta de clip inválida')
        return asset(path,info['sha256'])

    def playEvent(self,event,language,text,emotion,allowed_variants=()):
        row=self.findClip(event,language,text,emotion,allowed_variants)
        return self.preload(row) if row else None

    def clearCache(self):
        # Playback reads one byte-verified local file at a time.
        return 0
