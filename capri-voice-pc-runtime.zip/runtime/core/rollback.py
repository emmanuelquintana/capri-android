"""Verify or restore the byte-exact Spanish V6 profile into a new directory."""
from argparse import ArgumentParser
from pathlib import Path
import shutil

from engine import ROOT, asset, read


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--restore',type=Path)
    options=parser.parse_args()
    folder=ROOT/'profiles/es-MX-best'
    locks=read(folder/'LOCK.json')
    for name,digest in locks.items():
        asset(folder/name,digest)
    if options.restore:
        shutil.copytree(folder,options.restore)
        for name,digest in locks.items():
            asset(options.restore/name,digest)
        print(options.restore.resolve())
    print('es-MX-best · 4.0.0-icl · SHA-256 verificado')


if __name__=='__main__':
    main()
