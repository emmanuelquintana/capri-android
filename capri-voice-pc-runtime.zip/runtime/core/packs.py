"""Trusted optional package downloads and local private clip installation."""
import argparse
import os
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

from engine import ROOT, sha
sys.path.insert(0,str(ROOT/'sdk'))
from capri_voice.clips import VoicePackManager


def https(url):
    p=urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password:
        raise ValueError('Se requiere URL HTTPS sin credenciales')
    return url


class HTTPSOnly(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        return super().redirect_request(req,fp,code,msg,headers,https(newurl))


def download(url, target, checksum, total, consent=False, progress=None, cancelled=None):
    if not consent:
        raise ValueError('Confirma explícitamente la descarga')
    if not isinstance(total,int) or not 0<total<=20*1024**3 or not re.fullmatch(r'[a-f0-9]{64}',checksum):
        raise ValueError('Se requieren tamaño y hash confiables')
    target=Path(target)
    if target.is_file():
        if target.stat().st_size==total and sha(target)==checksum:
            return target
        raise FileExistsError(f'Recurso existente diferente: {target}')
    https(url)
    partial=target.with_suffix(target.suffix+'.partial-'+checksum[:16])
    target.parent.mkdir(exist_ok=True,parents=True)
    offset=partial.stat().st_size if partial.exists() else 0
    if offset>total:
        raise ValueError(f'Temporal excede el tamaño esperado: {partial}')
    if offset<total:
        headers={'Accept-Encoding':'identity'}
        if offset:
            headers['Range']=f'bytes={offset}-'
        with build_opener(HTTPSOnly()).open(Request(url,headers=headers),timeout=30) as response:
            if response.status==206:
                expected=f'bytes {offset}-{total-1}/{total}'
                if response.headers.get('Content-Range')!=expected:
                    raise ValueError('Content-Range distinto del solicitado')
            elif response.status==200:
                offset=0
            else:
                raise ValueError(f'HTTP {response.status}')
            with partial.open('ab' if offset else 'wb') as stream:
                while chunk:=response.read(1024*1024):
                    if cancelled and cancelled():
                        raise InterruptedError('Descarga pausada; el parcial se conserva')
                    offset+=len(chunk)
                    if offset>total:
                        raise ValueError('La descarga excede el tamaño indicado')
                    stream.write(chunk)
                    if progress:
                        progress(offset,total)
    if partial.stat().st_size!=total:
        raise ValueError('Descarga incompleta. Ejecuta de nuevo el comando para continuar.')
    if sha(partial)!=checksum:
        raise ValueError(f'SHA-256 distinto. Revisa el temporal: {partial}')
    if target.exists():
        raise FileExistsError(f'El destino apareció durante la descarga: {target}')
    if os.name=='nt':
        partial.rename(target)
    else:
        os.link(partial,target)
        partial.unlink()
    return target


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT/'studio/data/packs')
    p.add_argument('--private',action='store_true')
    commands=p.add_subparsers(dest='action',required=True)
    commands.add_parser('list')
    for command in ('verify','uninstall'):
        commands.add_parser(command).add_argument('id')
    for command in ('check','install','repair'):
        item=commands.add_parser(command)
        item.add_argument('archive',type=Path)
        item.add_argument('sha256')
    net=commands.add_parser('download')
    for key in ('url','target','sha256'):
        net.add_argument(key)
    net.add_argument('size',type=int)
    net.add_argument('--consent',action='store_true')
    net.add_argument('--progress',action='store_true')
    a=p.parse_args()
    m=VoicePackManager(a.root,a.private)
    if a.action=='download':
        def progress(done,total):
            print(f'{done}/{total}',file=sys.stderr,flush=True)
        try:
            print(download(a.url,a.target,a.sha256,a.size,a.consent,progress if a.progress else None))
        except KeyboardInterrupt:
            p.exit(130,'Descarga pausada. El parcial se conserva.\n')
    elif a.action=='list':
        print(*m.list_packs(),sep='\n')
    elif a.action=='check':
        print(m.check_compatibility(a.archive,a.sha256)['id'])
    elif a.action in ('install','repair'):
        print(getattr(m,a.action)(a.archive,a.sha256)['id'])
    elif a.action=='verify':
        print(m.verify(a.id)['id'])
    else:
        m.uninstall(a.id)


if __name__=='__main__':
    main()
