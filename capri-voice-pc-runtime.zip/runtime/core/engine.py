"""Local profile loader. Model paths are separate from immutable voice manifests."""
from hashlib import file_digest
import json
import os
from pathlib import Path
import shutil
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with Path(path).open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def asset(path, expected):
    if not Path(path).is_file() or sha(path) != expected:
        raise ValueError(f'Recurso ausente o SHA-256 incorrecto: {path}')
    return path


def resource(name):
    entry = read(ROOT/'resources.json')[name]
    configured=os.environ.get(entry['env'])
    options = [configured] if configured else [ROOT/entry['relative'], entry['local_discovery']]
    if not configured and name=='ffmpeg':
        options.append(shutil.which('ffmpeg'))
    for path in options:
        if path and Path(path).exists():
            return Path(path).resolve()
    raise FileNotFoundError(f'Configura {entry["env"]} para {name}')


class Engine:
    def __init__(self, engine, language, device):
        import numpy as np
        import torch
        from importlib.metadata import version

        os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        self.engine, self.language, self.device = engine, language, device
        self.torch, self.np = torch, np
        self.voice = None
        started=perf_counter()
        if device == 'cpu':
            torch.set_num_threads(6)
        elif device == 'cuda:0':
            free,total=torch.cuda.mem_get_info()
            limit=float(os.environ.get('CAPRI_VRAM_GIB','6'))*1024**3
            if not 0<limit<=free:
                raise RuntimeError('VRAM disponible insuficiente para el presupuesto configurado')
            torch.cuda.set_per_process_memory_fraction(min(1,limit/total))
        else:
            raise ValueError('Dispositivo desconocido')
        if engine in ('qwen06','qwen17'):
            from qwen_tts import Qwen3TTSModel
            from qwen_tts.inference.qwen3_tts_model import VoiceClonePromptItem
            from transformers import modeling_utils
            from read_checkpoint import ReadOnlyCheckpoint

            if language=='es-MX' and engine!='qwen06':
                raise ValueError('El perfil V6 solo corresponde a Qwen 0.6B')
            meta=read(ROOT/'profiles/es-MX-best/profile.json')
            mapped=resource(engine)
            if engine=='qwen06':
                for name,digest in meta['model_sha256'].items():
                    asset(mapped/name,digest)
            else:
                for item in read(ROOT/'reports/weight-locks.json')['Qwen/Qwen3-TTS-12Hz-1.7B-Base']:
                    asset(mapped/item['file'],item['sha256'])
            modeling_utils.safe_open=ReadOnlyCheckpoint
            modeling_utils.caching_allocator_warmup=lambda *args,**kwargs: None
            self.model=Qwen3TTSModel.from_pretrained(str(mapped), device_map=device, dtype=torch.bfloat16,
                                                    attn_implementation='sdpa',local_files_only=True)
            model_config=self.model.model.config
            if model_config.tts_model_type!='base' or model_config.tts_model_size!=('0b6' if engine=='qwen06' else '1b7'):
                raise ValueError('Modelo Base incompatible')
            self.params=meta['parameters']
            if language=='es-MX':
                folder=ROOT/'profiles/es-MX-best'
                for name,digest in read(folder/'LOCK.json').items():
                    asset(folder/name,digest)
                with np.load(folder/'prompt.npz',allow_pickle=False) as vectors:
                    self.voice=VoiceClonePromptItem(torch.from_numpy(vectors['ref_code']).to(device),
                        torch.from_numpy(vectors['ref_spk_embedding']).to(device,dtype=torch.bfloat16),False,True,meta['reference']['text'])
            elif language=='en-US':
                source=read(ROOT/'profiles/en-US-source/conditioning.json')
                ref=asset(ROOT/source['file'],source['sha256'])
                with torch.inference_mode():
                    self.voice,=self.model.create_voice_clone_prompt(ref_audio=str(ref),ref_text=source['text'],x_vector_only_mode=False)
            else:
                raise ValueError('Idioma no disponible')
            if not self.voice.icl_mode or self.voice.x_vector_only_mode or self.voice.ref_code is None:
                raise RuntimeError('El motor no activó ICL')
            self.revision=meta['model_revision'] if engine=='qwen06' else 'fd4b254389122332181a7c3db7f27e918eec64e3'
            self.version=version('qwen-tts')
        elif engine=='turbo' and language=='en-US':
            from capri_voice.chatterbox import ChatterboxEngine, REVISION
            from read_checkpoint import ReadOnlyCheckpoint
            import safetensors.torch

            self.model=ChatterboxEngine(device)
            original=safetensors.torch.safe_open
            try:
                safetensors.torch.safe_open=lambda filename,framework,device='cpu',**_: ReadOnlyCheckpoint(filename,framework,device)
                self.model.load_model(resource('turbo'))
                self.model.load_voice_profile(ROOT/'profiles/en-US-turbo/profile.json')
            finally:
                safetensors.torch.safe_open=original
            self.revision=REVISION
            self.version=version('chatterbox-tts')
            self.params={'seed':417,'max_audio_tokens':512}
        elif engine=='multilingual' and language=='en-US':
            from chatterbox.mtl_tts import ChatterboxMultilingualTTS
            from chatterbox.models.tokenizers import tokenizer

            directory=resource(engine)
            for item in read(ROOT/'reports/weight-locks.json')['ResembleAI/chatterbox Multilingual T3 v2']:
                asset(directory/item['file'],item['sha256'])
            original=tokenizer.ChineseCangjieConverter
            try:
                tokenizer.ChineseCangjieConverter=lambda _: None
                self.model=ChatterboxMultilingualTTS.from_local(directory,device,t3_model='v2')
            finally:
                tokenizer.ChineseCangjieConverter=original
            source=read(ROOT/'profiles/en-US-source/conditioning.json')
            self.model.prepare_conditionals(str(asset(ROOT/source['file'],source['sha256'])),exaggeration=.5)
            self.revision='5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18'
            self.version=version('chatterbox-tts')
            self.params={'exaggeration':.5,'cfg_weight':.5,'temperature':.8,'repetition_penalty':1.2,'min_p':.05,'top_p':1.0}
        else:
            raise ValueError('Motor y perfil incompatibles')
        self.initialization_s=perf_counter()-started

    def synthesize(self, text, seed=937, exaggeration=None):
        import psutil
        if not isinstance(text,str) or not 1<=len(text.strip())<=600:
            raise ValueError('Se requiere texto de 1 a 600 caracteres')
        parameters=self.params.copy()
        if exaggeration is not None:
            if self.engine!='multilingual' or not .5<=exaggeration<=.9:
                raise ValueError('Intensidad solo disponible para Multilingual, de 0.5 a 0.9')
            parameters['exaggeration']=exaggeration
        started=perf_counter()
        self.torch.manual_seed(seed)
        gpu=self.device=='cuda:0'
        if gpu:
            self.torch.cuda.reset_peak_memory_stats()
        with self.torch.inference_mode():
            if self.engine=='turbo':
                audio=self.model.synthesize(text,'en-US')
                samples,rate=self.np.frombuffer(audio.pcm,dtype='<f4'),audio.sample_rate
                seed=417
            elif self.engine=='multilingual':
                samples=self.model.generate(text,language_id='en',**parameters).squeeze().float().cpu().numpy()
                rate=self.model.sr
            else:
                wav,rate=self.model.generate_voice_clone(text=text,language={'es-MX':'Spanish','en-US':'English'}[self.language],
                                                         voice_clone_prompt=[self.voice],**parameters)
                samples,=wav
        if gpu:
            self.torch.cuda.synchronize()
        elapsed=perf_counter()-started
        assert samples.ndim==1 and len(samples) and self.np.isfinite(samples).all(), 'PCM inválido'
        process=psutil.Process().memory_info()
        duration=len(samples)/rate
        return samples,rate,{'engine':self.engine,'revision':self.revision,'engine_version':self.version,'device':self.device,
            'parameters':parameters,'seed':seed,'generation_s':elapsed,'initialization_s':self.initialization_s,
            'duration_s':duration,'rtf':elapsed/duration,'ram_peak_bytes':getattr(process,'peak_wset',process.rss),
            'vram_allocated_bytes':self.torch.cuda.max_memory_allocated() if gpu else None}
