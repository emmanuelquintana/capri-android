"""Loopback sidecar used by Studio and desktop integration."""
from argparse import ArgumentParser
from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
from queue import Queue, Empty
import re
import secrets
import shutil
import subprocess
import sys
import threading
from time import monotonic, time
import unicodedata
from urllib.parse import unquote, urlsplit
import uuid
import webbrowser

from batch import save
from engine import ROOT, read, resource
from library import VoiceClipLibrary
sys.path.insert(0,str(ROOT/'sdk'))
from capri_voice.clips import VoicePackManager, verify_file

ENGINES={'qwen06':('es-MX','en-US'),'qwen17':('en-US',),'turbo':('en-US',),'multilingual':('en-US',)}
DEVICES={'qwen06':'cuda:0','qwen17':'cpu','turbo':'cpu','multilingual':'cuda:0'}
CHILD_ENV='CAPRI_CHATTERBOX_PYTHON'
STATES={'started':'VOICE_STARTED','progress':'VOICE_PROGRESS','finished':'VOICE_FINISHED',
        'cancelled':'VOICE_CANCELLED','error':'VOICE_ERROR'}
BUSY=('VOICE_REQUESTED','VOICE_PREPARING')
DATA=Path(os.environ.get('CAPRI_STUDIO_DATA', ROOT/'studio/data')).resolve()


def hardware():
    import psutil

    result=dict(platform=sys.platform,architecture=os.environ.get('PROCESSOR_ARCHITECTURE'),
                ram_available_bytes=psutil.virtual_memory().available,
                disk_free_bytes=shutil.disk_usage(DATA).free)
    if sys.platform=='win32':
        from ctypes import Structure, sizeof, byref, windll, c_ulong, c_ulonglong

        class Memory(Structure):
            _fields_=[('length',c_ulong),('load',c_ulong),
                      *[(name,c_ulonglong) for name in ('total_physical','available_physical',
                        'total_commit','available_commit','total_virtual','available_virtual','extended')]]
        status=Memory()
        status.length=sizeof(status)
        if windll.kernel32.GlobalMemoryStatusEx(byref(status)):
            result['commit_available_bytes']=status.available_commit
    try:
        response=subprocess.run(['nvidia-smi','--query-gpu=name,memory.free,memory.total','--format=csv,noheader,nounits'],
                                capture_output=True,text=True,timeout=3,check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        name,free,total=(part.strip() for part in response.stdout.splitlines()[0].split(','))
        result.update(gpu=name,vram_available_bytes=int(free)*1024**2,vram_bytes=int(total)*1024**2)
    except (OSError,subprocess.SubprocessError,ValueError,IndexError):
        pass
    return result


def backend_executable(engine):
    local=Path(r'D:\CodexVoiceTests\capri-voice-packs-20261118\chatterbox-env\Scripts\python.exe')
    if engine in ('turbo','multilingual'):
        return os.environ.get(CHILD_ENV, str(local) if local.is_file() else sys.executable)
    return sys.executable


def available(engine):
    try:
        return resource(engine).is_dir() and Path(backend_executable(engine)).is_file()
    except FileNotFoundError:
        return False


def listed_profiles(language):
    profiles=[dict(id='es-MX-best',engine='qwen06',version='4.0.0-icl')]
    if language=='en-US':
        preferred=english_profile()
        profiles=[dict(id='en-US-best' if engine==preferred else f'en-US-{engine}',
                       engine=engine,version='7.0.0-pilot') for engine in ENGINES]
    return [p for p in profiles if available(p['engine'])]


def english_profile():
    decision=ROOT/'profiles/en-US-best/profile.json'
    if decision.is_file():
        return read(decision)['engine']
    return None


def recommend(language):
    if language=='es-MX':
        return 'qwen06'
    preferred=english_profile()
    if preferred and available(preferred):
        return preferred
    raise ValueError('Perfil inglés sin validación técnica o sin recursos instalados')


class Worker:
    def __init__(self,key):
        self.key=key
        engine,_,_=key
        env=os.environ.copy()
        env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
        env['CAPRI_PARENT_PID']=str(os.getpid())
        if engine in ('turbo','multilingual') and backend_executable(engine)!=sys.executable:
            path=str(Path(sys.executable).parent.parent/'Lib/site-packages')
            env['PYTHONPATH']=os.pathsep.join(filter(None,(env.get('PYTHONPATH'),path)))
        with (DATA/'worker.log').open('a',encoding='utf8') as log:
            self.process=subprocess.Popen([backend_executable(engine),'-u',str(ROOT/'core/worker.py'),*key],
                                          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,
                                          encoding='utf8',env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.lines=Queue()
        threading.Thread(target=self.read,daemon=True).start()

    def read(self):
        for line in self.process.stdout:
            try:
                self.lines.put(json.loads(line))
            except json.JSONDecodeError:
                continue
        self.lines.put({'error':'El proceso de síntesis terminó. Consulta worker.log.'})

    def receive(self):
        try:
            message=self.lines.get(timeout=360)
        except Empty:
            raise RuntimeError('Tiempo de inferencia agotado') from None
        if message.get('error'):
            raise RuntimeError(message['error'])
        return message

    def request(self,body,progress):
        self.process.stdin.write(json.dumps(body)+'\n')
        self.process.stdin.flush()
        while True:
            message=self.receive()
            if 'metrics' in message:
                return message['metrics']
            progress(message)

    def close(self):
        self.process.kill()
        self.process.wait(timeout=10)
        self.process.stdin.close()


class VoiceManager:
    def __init__(self, allow_private_clips=False):
        self.lock=threading.RLock()
        self.job=None
        self.worker=None
        self.timer=None
        self.selection={}
        self.jobs={}
        self.pending=[]
        self.delivered_ids={}
        self.closing=False
        self.clips=VoiceClipLibrary(allow_private=allow_private_clips)
        self.packs=VoicePackManager(DATA/'packs',allow_private_clips)
        DATA.mkdir(parents=True,exist_ok=True)
        (DATA/'audio').mkdir(exist_ok=True)
        (DATA/'history').mkdir(exist_ok=True)

    def capabilities(self,language):
        return dict(hardware=hardware(),engines=[dict(id=e,installed=available(e),default_device=DEVICES[e],
                    languages=ls) for e,ls in ENGINES.items()],profiles=listed_profiles(language),
                   streaming='delivery of completed audio',speed=[1.0],
                   fx=['OFF','LIGHT','SIGNATURE'] if language=='es-MX' else ['OFF'],
                   performance='Device budgets; automatic selection keeps the independently validated identity',
                   modes=['automatic','light','balanced','fidelity','manual'])

    def emit(self,job,state,update=True,**values):
        event={'state':state,'request_id':job['id'],'emotion':job['emotion'],'priority':job['priority'],
               'text':job['texts'][0],'language':job['language'],'visual_event':job['visual_event'],
               'at_unix_s':time(),'playback_ms':values.pop('playback_ms',0),**values}
        job['events'].append(event)
        if update:
            job['state']=state

    def select(self, request, remember=True):
        language=request['language']
        if language not in ('es-MX','en-US'):
            raise ValueError('Idioma inválido')
        mode=request.get('mode','automatic')
        if mode not in ('automatic','light','balanced','fidelity','manual'):
            raise ValueError('Modo inválido')
        engine=request.get('engine') if mode=='manual' else recommend(language)
        profile='es-MX-best' if language=='es-MX' else f'en-US-{engine}'
        if engine not in ENGINES or language not in ENGINES[engine] or not available(engine):
            raise ValueError('Motor no disponible para este perfil')
        aliases={profile}
        if language=='en-US' and engine==english_profile():
            aliases.add('en-US-best')
        if request.get('profile') and request['profile'] not in aliases:
            raise ValueError('El cambio de identidad requiere seleccionar el perfil correspondiente')
        device=request.get('device') or ('cpu' if mode=='light' else DEVICES[engine])
        if device not in ('cpu','cuda:0') or engine=='turbo' and device!='cpu':
            raise ValueError('Dispositivo no compatible con este backend')
        kit=hardware()
        min_ram=int(os.environ.get('CAPRI_MIN_RAM_MIB','3000'))*1024**2
        expected={'qwen06':4,'qwen17':7,'turbo':4,'multilingual':4}[engine]*1024**3
        resident=self.worker and self.worker.key==(engine,language,device)
        if kit['ram_available_bytes']<min_ram:
            raise ValueError('Memoria libre insuficiente')
        if not resident and kit.get('commit_available_bytes',expected)<expected:
            raise ValueError('Memoria comprometible insuficiente para cargar este motor')
        if device=='cuda:0' and kit.get('vram_available_bytes',0)<float(os.environ.get('CAPRI_VRAM_GIB','6'))*1024**3:
            if mode not in ('manual','fidelity'):
                device='cpu'
            else:
                raise ValueError('VRAM libre insuficiente')
        selection=dict(language=language,mode=mode,engine=engine,profile=request.get('profile') or profile,device=device)
        if remember:
            self.selection=selection
        return selection

    def synthesize(self,request):
        entries=request.get('texts')
        language=request.get('language')
        speed=request.get('speed',1.0)
        if language not in ('es-MX','en-US') or type(speed) not in (int,float) or speed!=1:
            raise ValueError('Idioma inválido o velocidad distinta de 1')
        preset=request.get('preset') or ('SIGNATURE' if language=='es-MX' else 'OFF')
        if preset not in (('OFF','LIGHT','SIGNATURE') if language=='es-MX' else ('OFF',)):
            raise ValueError('Acabado incompatible con el idioma')
        request={**request,'preset':preset}
        exaggeration=request.get('exaggeration')
        if exaggeration is not None and (language!='en-US' or type(exaggeration) not in (float,int)
                                        or exaggeration not in (.5,.8)):
            raise ValueError('Control interpretativo incompatible')
        if (not isinstance(entries,list) or not 1<=len(entries)<=20 or
            any(not isinstance(t,str) or not 1<=len(t.strip())<=12000 for t in entries) or
            sum(map(len,entries))>24000):
            raise ValueError('Límite de 20 textos, 12 000 caracteres por texto y 24 000 por trabajo')
        seeds=request.get('seeds',[937])
        if not isinstance(seeds,list) or not 1<=len(seeds)<=3 or any(type(s)!=int or not 0<=s<=2**32-1 for s in seeds):
            raise ValueError('Usa de 1 a 3 semillas enteras')
        if len(entries)*len(seeds)>20:
            raise ValueError('El lote excede 20 tomas')
        emotion=request.get('emotion','neutral')
        if not isinstance(emotion,str) or len(emotion)>32:
            raise ValueError('Emoción inválida')
        priority=request.get('priority',0)
        if type(priority)!=int or not 0<=priority<=9:
            raise ValueError('Prioridad inválida')
        external=request.get('dedupe_id')
        if external is not None and (not isinstance(external,str) or not 1<=len(external)<=128):
            raise ValueError('ID de mensaje inválido')
        with self.lock:
            if external and external in self.delivered_ids:
                return self.snapshot(self.delivered_ids[external])
            if len(self.pending)>=6 or self.closing:
                raise ValueError('Cola llena o en cierre')
            job=dict(id=uuid.uuid4().hex,emotion=emotion,priority=priority,events=[],results=[],
                     texts=entries,language=language,visual_event=request.get('event'),preset=preset,requested_at=monotonic())
            self.jobs[job['id']]=job
            if len(self.jobs)>80:
                older=next((k for k,v in self.jobs.items() if v is not self.job and v['state'] not in BUSY),None)
                if older:
                    self.jobs.pop(older)
                    self.delivered_ids={k:v for k,v in self.delivered_ids.items() if v!=older}
            if external:
                self.delivered_ids[external]=job['id']
                if len(self.delivered_ids)>256:
                    self.delivered_ids.pop(next(iter(self.delivered_ids)))
            self.emit(job,'VOICE_REQUESTED')
            self.pending.append((job,request,entries,seeds))
            self.pending.sort(key=lambda item:-item[0]['priority'])
            if self.job and self.job['state'] in BUSY and request.get('interrupt') is True and priority>self.job['priority']:
                self.cancel(self.job['id'],dispatch=False)
            self.dispatch()
            return self.snapshot(job['id'])

    def dispatch(self):
        if self.pending and not self.closing and not (self.job and self.job['state'] in BUSY):
            args=self.pending.pop(0)
            self.job=args[0]
            threading.Thread(target=self.prepare,args=args,daemon=True).start()

    def prepare(self,job,request,entries,seeds):
        queued=job['requested_at']
        with self.lock:
            if job['state']=='VOICE_CANCELLED':
                return
            self.emit(job,'VOICE_PREPARING')
        try:
            if request.get('event') and len(entries)==len(seeds)==1 and request.get('speed',1)==1:
                variants=request.get('variants',[])
                if not isinstance(variants,list) or not all(isinstance(v,str) for v in variants):
                    raise ValueError('Variantes inválidas')
                text=entries[0]
                language=request['language']
                packed,clip=None,None
                for variant in (job['emotion'],*variants):
                    packed=self.find_installed(request['event'],language,text,variant,request['preset'])
                    clip=self.clips.findClip(request['event'],language,text,variant) if request['preset']=='OFF' else None
                    if packed or clip:
                        break
                if packed:
                    row,opus=packed
                    wav=DATA/'audio'/f"{job['id']}-0.wav"
                    subprocess.run([str(resource('ffmpeg')),'-nostdin','-v','error','-xerror','-y',
                                    '-i',str(opus),'-c:a','pcm_s16le',str(wav)],check=True,timeout=15)
                    resolved=(wav,opus,row.get('seed'),row['durationMs']/1000)
                elif clip:
                    resolved=(self.clips.preload(clip),self.clips.preload(clip,'opus'),clip['seed'],clip['duration_s'])
                else:
                    resolved=None
                if resolved:
                    with self.lock:
                        if job['state']=='VOICE_CANCELLED':
                            return
                        wav,opus,seed,duration=resolved
                        result=self.result(job,text,seed,wav,opus,
                                           {'source':'clip','duration_s':duration,'ready_s':monotonic()-queued,
                                            'engine':row.get('engine') if packed else clip['engine'],
                                            'profile':row.get('profile') if packed else clip['profile'],
                                            'processing':row.get('processing') if packed else {'preset':'OFF'}})
                        job['results'].append(result)
                        self.emit(job,'VOICE_READY',audio=result['wav'])
                    return
            with self.lock:
                if job['state']=='VOICE_CANCELLED':
                    return
                selected=self.select(request)
                if request.get('exaggeration') is not None and selected['engine']!='multilingual':
                    raise ValueError('El control interpretativo requiere Chatterbox Multilingual')
                if selected['engine']=='turbo' and len(seeds)>1:
                    raise ValueError('El perfil Turbo utiliza una semilla fija; solicita una toma por texto')
                if self.timer:
                    self.timer.cancel()
                key=(selected['engine'],selected['language'],selected['device'])
                if self.worker and self.worker.key!=key:
                    self.unload()
                fresh=self.worker is None
                if fresh:
                    self.worker=Worker(key)
                worker=self.worker
            if fresh:
                worker.receive()
            for text in entries:
                for seed in seeds:
                    with self.lock:
                        if job['state']=='VOICE_CANCELLED':
                            return
                    output=DATA/'audio'/f"{job['id']}-{len(job['results'])}.wav"
                    def progress(message):
                        with self.lock:
                            if job['state']!='VOICE_CANCELLED':
                                self.emit(job,'VOICE_PROGRESS',update=False,source='tts',**message)
                    metrics=worker.request(dict(text=text,seed=seed,output=str(output),preset=request['preset'],
                                                exaggeration=request.get('exaggeration')),progress)
                    metrics.update(source='tts',ready_s=monotonic()-queued,profile=selected['profile'])
                    with self.lock:
                        if job['state']=='VOICE_CANCELLED':
                            return
                        result=self.result(job,text,metrics['seed'],output,output.with_suffix('.opus'),metrics)
                        job['results'].append(result)
            with self.lock:
                if job['state']=='VOICE_CANCELLED':
                    return
                self.emit(job,'VOICE_READY',audio=job['results'][0]['wav'])
                self.timer=threading.Timer(90,self.unload)
                self.timer.daemon=True
                self.timer.start()
        except (OSError,RuntimeError,ValueError,KeyError,subprocess.SubprocessError) as error:
            with self.lock:
                if job['state']!='VOICE_CANCELLED':
                    self.emit(job,'VOICE_UNAVAILABLE' if isinstance(error,ValueError) else 'VOICE_ERROR',error=str(error))
                    self.unload()
        finally:
            with self.lock:
                if job['results']:
                    save(DATA/'history'/f"{job['id']}.json",job)
                self.dispatch()

    def find_installed(self,event,language,text,emotion,preset):
        for pack_id in self.packs.list_packs():
            if not pack_id.startswith(f'capri-clips-{language}-') or pack_id.endswith('-demo'):
                continue
            try:
                library=self.packs.open_pack(pack_id)
                for row in library.list_clips():
                    if (row['emotion']==emotion and row.get('text')==text and
                        row.get('processing',{}).get('preset','OFF')==preset
                        and event in (row['eventId'],row.get('appEvent'))):
                        return row,verify_file(library.directory,row['asset'],row['bytes'],row['sha256'])
            except (OSError,ValueError,KeyError):
                continue
        return None

    def result(self,job,text,seed,wav,opus,metrics):
        with self.lock:
            actual=DATA/'audio'/f"{job['id']}-{len(job['results'])}"
            for source,suffix in ((wav,'.wav'),(opus,'.opus')):
                target=actual.with_suffix(suffix)
                if source!=target:
                    shutil.copy2(source,target)
            dry=actual.with_suffix('.dry.wav')
            return dict(text=text,seed=seed,wav=f'/audio/{actual.name}.wav',opus=f'/audio/{actual.name}.opus',
                        dry=f'/audio/{dry.name}' if dry.is_file() else None,metrics=metrics)

    def snapshot(self,job_id=None):
        with self.lock:
            job=self.jobs.get(job_id) if job_id else self.job
            return json.loads(json.dumps(job))

    def unload(self):
        with self.lock:
            if self.worker:
                self.worker.close()
                self.worker=None
            if self.timer:
                self.timer.cancel()
                self.timer=None

    def cancel(self,job_id=None,dispatch=True):
        with self.lock:
            job=self.jobs.get(job_id) if job_id else self.job
            if job and job['state']!='VOICE_CANCELLED':
                self.emit(job,'VOICE_CANCELLED')
                self.pending=[item for item in self.pending if item[0] is not job]
                if self.job is job:
                    self.unload()
                if dispatch:
                    self.dispatch()
            return self.snapshot(job_id or (job['id'] if job else None))

    def report_playback(self,body):
        with self.lock:
            job=self.jobs.get(body['id'])
            if not job or job['state']=='VOICE_CANCELLED':
                raise ValueError('Solicitud de reproducción vencida')
            audio=body['audio']
            result=next((item for item in job['results'] if item['wav']==audio),None)
            if result is None:
                raise ValueError('Audio ajeno a la solicitud')
            position=body.get('playback_ms',0)
            if type(position)!=int or not 0<=position<=300000:
                raise ValueError('Posición inválida')
            if len(job['events'])>=1000:
                raise ValueError('Límite de eventos de reproducción')
            meta=result['metrics']
            self.emit(job,STATES[body['event']],audio=audio,playback_ms=position,source=meta['source'],
                      engine=meta.get('engine'),profile=meta.get('profile'),duration_s=meta['duration_s'])
            return self.snapshot(job['id'])

    def favorite(self,body):
        with self.lock:
            if not self.job or body['id']!=self.job['id']:
                raise ValueError('Solicitud vencida')
            row=next((r for r in self.job['results'] if r['wav']==body['audio']),None)
            if row is None:
                raise ValueError('Audio ajeno a la solicitud')
            target=DATA/'favorites'/self.job['id']
            target.mkdir(parents=True,exist_ok=True)
            for fmt in ('wav','opus'):
                name=Path(row[fmt]).name
                shutil.copy2(DATA/'audio'/name,target/name)
            save(target/(Path(row['wav']).stem+'.json'),row)
            return {'path':str(target)}


def handler(manager, token):
    class Handler(BaseHTTPRequestHandler):
        def reply(self,body,status=200,content_type='application/json; charset=utf-8'):
            if not isinstance(body,bytes):
                body=json.dumps(body,ensure_ascii=False).encode('utf8')
            self.send_response(status)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy',"default-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(body)

        def media(self,path):
            size=path.stat().st_size
            start,end=0,size-1
            request=self.headers.get('Range')
            if request:
                segment=re.fullmatch(r'bytes=(\d{1,12})-(\d{0,12})',request)
                if segment:
                    start=int(segment[1])
                    end=min(end,int(segment[2])) if segment[2] else end
                if not segment or not 0<=start<=end<size:
                    self.send_response(416)
                    self.send_header('Content-Range',f'bytes */{size}')
                    self.send_header('Content-Length','0')
                    self.end_headers()
                    return
            self.send_response(206 if request else 200)
            self.send_header('Content-Type','audio/wav' if path.suffix=='.wav' else 'audio/ogg')
            self.send_header('Content-Length',str(end-start+1))
            self.send_header('Accept-Ranges','bytes')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            if request:
                self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            with path.open('rb') as stream:
                stream.seek(start)
                remaining=end-start+1
                try:
                    while remaining:
                        payload=stream.read(min(remaining,65536))
                        if not payload:
                            break
                        self.wfile.write(payload)
                        remaining-=len(payload)
                except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):
                    pass

        def owned(self):
            if self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}':
                self.reply({'error':'Host inválido'},403)
                return False
            return True

        def allowed(self):
            if not secrets.compare_digest(self.headers.get('X-Capri-Token',''),token):
                self.reply({'error':'Token de sesión inválido'},403)
                return False
            return True

        def do_GET(self):
            if not self.owned():
                return
            path=unquote(urlsplit(self.path).path)
            if path=='/':
                return self.reply((ROOT/'studio/index.html').read_bytes().replace(b'__CAPRI_TOKEN__',token.encode()),
                                  content_type='text/html; charset=utf-8')
            if path in ('/studio.css','/studio.js'):
                mime='text/css' if path.endswith('.css') else 'application/javascript'
                return self.reply((ROOT/'studio'/path[1:]).read_bytes(),content_type=mime+'; charset=utf-8')
            if path.startswith('/audio/'):
                # A 128-bit per-job handle doubles as the local media capability.
                filename=path.removeprefix('/audio/')
                parts=filename.partition('-')
                if len(parts[0])==32 and all(c in '0123456789abcdef' for c in parts[0]) and parts[1] and '/' not in filename and '\\' not in filename:
                    candidate=DATA/'audio'/filename
                    if candidate.is_file() and candidate.suffix in ('.wav','.opus'):
                        return self.media(candidate)
            if path.startswith('/api/') and self.allowed():
                if path=='/api/status':
                    return self.reply(manager.snapshot())
                if path.startswith('/api/jobs/'):
                    job_id=path.rsplit('/',1)[-1]
                    if not re.fullmatch('[0-9a-f]{32}',job_id):
                        return self.reply({'error':'ID inválido'},400)
                    return self.reply(manager.snapshot(job_id))
                if path=='/api/history':
                    files=sorted((DATA/'history').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:30]
                    return self.reply([read(f) for f in files])
                if path=='/api/metrics':
                    return self.reply([r['metrics'] for r in (manager.snapshot() or {}).get('results',[])])
                if path in ('/api/es-MX','/api/en-US'):
                    return self.reply(manager.capabilities(path.rsplit('/',1)[1]))
                if path=='/api/catalog':
                    custom=DATA/'catalog.json'
                    return self.reply(read(custom if custom.is_file() else ROOT/'catalogs/catalog.json'))
            elif path.startswith('/api/'):
                return
            self.reply({'error':'Ruta desconocida'},404)

        def do_POST(self):
            if not self.owned() or not self.allowed():
                return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 2<=length<=400_000:
                    raise ValueError('Longitud inválida')
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict):
                    raise ValueError('El cuerpo debe ser un objeto JSON')
                if self.path=='/api/synthesize':
                    return self.reply(manager.synthesize(data),202)
                if self.path=='/api/cancel':
                    return self.reply(manager.cancel(data.get('id')))
                if self.path=='/api/unload':
                    if manager.job and manager.job['state'] in BUSY:
                        return self.reply({'error':'Cancela la toma activa antes de liberar el motor'},409)
                    manager.unload()
                    return self.reply({'unloaded':True})
                if self.path=='/api/quit':
                    with manager.lock:
                        manager.closing=True
                        manager.pending.clear()
                    threading.Thread(target=self.server.shutdown,daemon=True).start()
                    return self.reply({'closing':True})
                if self.path=='/api/select':
                    return self.reply(manager.select(data))
                if self.path=='/api/recommend':
                    return self.reply(manager.select(data,remember=False))
                if self.path=='/api/playback':
                    return self.reply(manager.report_playback(data))
                if self.path=='/api/favorite':
                    return self.reply(manager.favorite(data))
                if self.path=='/api/catalog':
                    rows=data['entries']
                    if not isinstance(rows,list) or len(rows)>1000 or any(
                        not isinstance(row,dict) or row.get('language') not in ('es-MX','en-US') or
                        not isinstance(row.get('id'),str) or not re.fullmatch(r'[a-zA-Z0-9._-]{1,100}',row['id']) or
                        not isinstance(row.get('text'),str) or not 1<=len(row['text'].strip())<=600
                        for row in rows):
                        raise ValueError('Catálogo inválido')
                    texts={(row['language'],' '.join(unicodedata.normalize('NFC',row['text']).casefold().split()))
                           for row in rows}
                    ids={(row['language'], row['id'].casefold()) for row in rows}
                    if len(texts)!=len(rows) or len(ids)!=len(rows):
                        raise ValueError('El catálogo contiene IDs o textos duplicados por idioma')
                    previous=DATA/'catalog.json'
                    if previous.is_file():
                        save(DATA/'catalog-versions'/f'{time():.0f}-{uuid.uuid4().hex[:8]}.json',read(previous))
                    save(DATA/'catalog.json',data)
                    return self.reply({'entries':len(rows)})
                self.reply({'error':'Ruta desconocida'},404)
            except (TypeError,ValueError,KeyError) as error:
                self.reply({'error':str(error)},400)

    return Handler


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--allow-private-clips',action='store_true')
    parser.add_argument('--ready-file',type=Path)
    args=parser.parse_args()
    manager=VoiceManager(allow_private_clips=args.allow_private_clips or not args.no_browser)
    token=secrets.token_urlsafe(32)
    with ThreadingHTTPServer(('127.0.0.1',args.port),handler(manager,token)) as server:
        url=f'http://127.0.0.1:{server.server_port}/'
        if args.ready_file:
            save(args.ready_file,{'url':url,'token':token,'pid':os.getpid()})
        print(url,flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            manager.closing=True
            manager.cancel()


if __name__=='__main__':
    main()
