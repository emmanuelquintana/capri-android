"""Local Chatterbox Turbo; independently implemented CapriCore format reader.

Only the compatible GPT-2 Turbo adapter is accepted. Never load it into Qwen
or Chatterbox Multilingual. Original Resemble tokenizer/decoder/watermark stay.
"""
import gc
from pathlib import Path
import threading
import time

from .contract import Audio, Cancelled, asset, memory_bytes, profile, read_json, validate_text

REVISION = "749d1c1a46eb10492095d68fbcf55691ccf137cd"
SOURCE_REVISION = "5de7a54aa4e5e2baadb0182dde554908b48b85c2"


def merge_adapter(t3, metadata, tensors, torch):
    """Conv1D stores W[in,out]; safetensors stores A[rank,in], B[out,rank]."""
    from transformers.pytorch_utils import Conv1D
    settings = metadata["adapter"]
    rank, alpha = settings["rank"], settings["alpha"]
    if type(rank) is not int or not 1 <= rank <= 256 or type(alpha) not in (int, float) or not 0 < alpha <= 4096:
        raise ValueError("Invalid adapter rank/alpha")
    layers = {name: layer for name, layer in t3.named_modules() if name.startswith("tfmr.h.")
              and name.rsplit(".", 1)[-1] in {"c_attn", "c_proj", "c_fc"} and isinstance(layer, Conv1D)}
    expected = {name + ".lora_" + suffix for name in layers for suffix in ("A", "B")}
    if not layers or set(tensors) != expected:
        raise ValueError("Adapter projection names differ from pinned Turbo")
    for name, layer in layers.items():
        a, b = tensors[name + ".lora_A"], tensors[name + ".lora_B"]
        width_in, width_out = layer.weight.shape
        if tuple(a.shape) != (rank, width_in) or tuple(b.shape) != (width_out, rank):
            raise ValueError("Adapter shape mismatch: " + name)
        if not torch.isfinite(a).all() or not torch.isfinite(b).all():
            raise ValueError("Non-finite adapter: " + name)
    with torch.no_grad():
        for name, layer in layers.items():
            a, b = tensors[name + ".lora_A"], tensors[name + ".lora_B"]
            delta = (b.float() @ a.float()).T * (alpha / rank)
            candidate = layer.weight.float() + delta.to(layer.weight.device)
            if not torch.isfinite(candidate).all():
                raise ValueError("Adapter overflows base projection: " + name)
            layer.weight.copy_(candidate)


class ChatterboxEngine:
    def __init__(self, device="cpu"):
        if device not in {"cpu", "cuda:0", "mps"}:
            raise ValueError("Unsupported device")
        self.device = device
        self._operation = threading.RLock()
        self._cancelled = threading.Event()
        self._engine = self._voice = self._directory = None
        self._disposed = False
        self._hooks = []

    def initialize(self):
        with self._operation:
            if self._disposed:
                raise RuntimeError("Engine disposed; create a new instance")
            import os
            # The setup script alone downloads models; inference is always local.
            os.environ["HF_HUB_OFFLINE"] = "1"
            os.environ["TRANSFORMERS_OFFLINE"] = "1"
            import torch
            from chatterbox.tts_turbo import ChatterboxTurboTTS
            self._torch, self._class = torch, ChatterboxTurboTTS

    def load_model(self, directory):
        with self._operation:
            self.initialize()
            directory = Path(directory).resolve()
            lock = read_json(Path(__file__).with_name("chatterbox-models.json"))
            for item in lock["files"]:
                asset(directory, {"file": item["name"], "sha256": item["sha256"]})
                if (directory / item["name"]).stat().st_size != item["bytes"]:
                    raise ValueError("Invalid base model size")
            self._release_model()
            self._directory = directory
            self._engine = self._class.from_local(directory, device=self.device)

    def load_voice_profile(self, manifest):
        with self._operation:
            if self._disposed or not self._engine:
                raise RuntimeError("Load a model first")
            voice = profile(manifest, "chatterbox-turbo", REVISION)
            if voice["languages"] != ["en-US"] or "reference_path" not in voice:
                raise ValueError("Turbo requires an authorized English reference")
            state = None
            if "capricore_profile_path" in voice:
                core_path = voice["capricore_profile_path"]
                core = read_json(core_path)
                expected = read_json(Path(__file__).with_name("chatterbox-upstream.json"))
                if core.get("engine") != "chatterbox-turbo" or core.get("language") != "en" or core.get("baseModel") != expected["model"]:
                    raise ValueError("Incompatible CapriCore base model/engine/language")
                adapter_path = asset(core_path.parent, {"file": core["adapter"], "sha256": core["adapterSha256"]})
                ref = asset(core_path.parent, core["references"]["neutral"])
                if ref != voice["reference_path"]:
                    raise ValueError("Manifest reference differs from CapriCore profile")
                metadata = read_json(voice["adapter_config_path"])
                if metadata.get("upstream") != expected or metadata.get("language") != "en":
                    raise ValueError("Adapter was trained against another source/model revision")
                from safetensors.torch import load_file
                state = load_file(str(adapter_path), device="cpu")
            # Re-read base weights when switching voices; never stack adapter deltas.
            if self._voice is not None:
                self._release_model()
                self._engine = self._class.from_local(self._directory, device=self.device)
            try:
                if state is not None:
                    merge_adapter(self._engine.t3, metadata, state, self._torch)
                self._engine.t3.eval()
                self._engine.prepare_conditionals(str(voice["reference_path"]), norm_loudness=False)
                self._voice = voice
                self._hooks = [module.register_forward_pre_hook(self._check_step) for module in
                               (self._engine.t3.tfmr, self._engine.s3gen)]
            except Exception:
                self._release_model()
                raise

    def _check_step(self, *_):
        if self._cancelled.is_set():
            raise Cancelled("Synthesis cancelled; partial audio discarded")

    def synthesize(self, text, language="en-US", max_audio_tokens=512):
        with self._operation:
            if self._disposed:
                raise RuntimeError("Engine disposed")
            validate_text(text, language, self._voice)
            if type(max_audio_tokens) is not int or not 16 <= max_audio_tokens <= 512:
                raise ValueError("max_audio_tokens must be 16–512")
            self._cancelled.clear()
            engine, torch = self._engine, self._torch
            native = engine.t3.inference_turbo
            def bounded(**kwargs):
                self._check_step()
                tokens = native(**kwargs, max_gen_len=max_audio_tokens)
                if tokens.shape[-1] >= max_audio_tokens:
                    raise RuntimeError("Generation token limit reached; partial audio discarded")
                return tokens
            engine.t3.inference_turbo = bounded
            started = time.perf_counter()
            try:
                with torch.inference_mode():
                    torch.manual_seed(417)  # Match the pinned CapriCore voice preset.
                    audio = engine.generate(text).squeeze().detach().cpu().numpy()
                self._check_step()
                return Audio(audio.astype("<f4").tobytes(), engine.sr, self._voice["id"],
                             (time.perf_counter() - started) * 1000, memory_bytes())
            finally:
                engine.t3.inference_turbo = native

    def cancel(self):
        self._cancelled.set()

    def _release_model(self):
        for hook in self._hooks:
            hook.remove()
        self._hooks = []
        self._engine = self._voice = None
        gc.collect()
        if hasattr(self, "_torch") and self._torch.cuda.is_available():
            self._torch.cuda.empty_cache()

    def dispose(self):
        self._disposed = True
        self.cancel()
        with self._operation:
            self._release_model()
            self._disposed = True
