"""Standalone auditions and a JSON-lines sidecar for the Tauri/Rust host."""
import argparse
import base64
from dataclasses import asdict
import json
from pathlib import Path
import sys
import threading

from .contract import Cancelled


def serve(engine, source, output):
    """One synthesis in flight; cancellation remains readable while it runs."""
    output_lock = threading.Lock()
    worker = None
    active_cancel = threading.Event()
    def reply(identifier, **value):
        with output_lock:
            output.write(json.dumps({"id": identifier, **value}, ensure_ascii=False) + "\n")
            output.flush()
    def synthesis(request, cancelled):
        try:
            if cancelled.is_set():
                raise Cancelled("Request cancelled before generation")
            audio = engine.synthesize(request["text"], request["language"], request.get("max_audio_tokens", 512))
            if cancelled.is_set():
                raise Cancelled("Request cancelled; generated audio discarded")
            data = asdict(audio)
            data["pcm_f32le_base64"] = base64.b64encode(data.pop("pcm")).decode("ascii")
            reply(request.get("id"), ok=True, audio=data)
        except Exception as error:
            reply(request.get("id"), ok=False, cancelled=isinstance(error, Cancelled), error=str(error))
    try:
        while True:
            line = source.readline(1024 * 1024 + 1)
            if not line:
                break
            request = {}
            try:
                if len(line) > 1024 * 1024:
                    raise ValueError("Request exceeds 1 MiB; closing sidecar")
                request = json.loads(line)
                if not isinstance(request, dict):
                    raise ValueError("Request must be an object")
                method = request.get("method")
                identifier = request.get("id")
                if method in {"cancel", "dispose"}:
                    active_cancel.set()
                    engine.cancel()
                    if method == "dispose":
                        if worker:
                            worker.join()
                        engine.dispose()
                        reply(identifier, ok=True)
                        break
                    reply(identifier, ok=True)
                    continue
                if worker and worker.is_alive():
                    raise RuntimeError("Synthesis busy; cancel or await its response first")
                if method == "initialize":
                    engine.initialize()
                elif method == "loadModel":
                    engine.load_model(request["directory"])
                elif method == "loadVoiceProfile":
                    engine.load_voice_profile(request["manifest"])
                elif method == "synthesize":
                    active_cancel = threading.Event()
                    worker = threading.Thread(target=synthesis, args=(request, active_cancel), name="capri-tts")
                    worker.start()
                    continue
                else:
                    raise ValueError("Unknown method")
                reply(identifier, ok=True)
            except Exception as error:
                reply(request.get("id") if isinstance(request, dict) else None, ok=False, error=str(error))
                if len(line) > 1024 * 1024:
                    break
    finally:
        active_cancel.set()
        engine.cancel()
        if worker:
            worker.join()
        engine.dispose()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["say", "serve"])
    parser.add_argument("--engine", choices=["qwen", "chatterbox"], required=True)
    parser.add_argument("--library", type=Path, help="Qwen native shared library")
    parser.add_argument("--cache", type=Path, default=Path(".local/cache"))
    parser.add_argument("--models", type=Path)
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--language", choices=["es-MX", "en-US"], default="es-MX")
    parser.add_argument("--device", choices=["cpu", "cuda:0", "mps"], default="cpu")
    parser.add_argument("--text")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.engine == "qwen":
        if not args.library:
            parser.error("Qwen requires --library")
        from .qwen import QwenEngine
        engine = QwenEngine(args.library, args.cache)
    else:
        from .chatterbox import ChatterboxEngine
        engine = ChatterboxEngine(args.device)
    output = sys.stdout
    # Keep upstream Python diagnostic prints out of the JSON protocol.
    sys.stdout = sys.stderr
    try:
        if args.mode == "serve":
            serve(engine, sys.stdin, output)
        else:
            if not all((args.models, args.profile, args.text, args.output)):
                parser.error("say requires --models, --profile, --text and --output")
            engine.initialize()
            engine.load_model(args.models)
            engine.load_voice_profile(args.profile)
            audio = engine.synthesize(args.text, args.language)
            audio.write_wav(args.output)
            print(json.dumps({"output": str(args.output.resolve()), "profile_id": audio.profile_id,
                "sample_rate": audio.sample_rate, "generation_ms": audio.generation_ms,
                "process_rss_bytes": audio.process_rss_bytes}), file=output)
    except Exception as error:
        print(json.dumps({"ok": False, "error": str(error)}), file=output)
        raise SystemExit(1)
    finally:
        engine.dispose()
        sys.stdout = output


if __name__ == "__main__":
    main()
