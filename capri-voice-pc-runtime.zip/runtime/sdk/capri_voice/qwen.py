"""ctypes binding to the pinned Qwen C ABI; same GGUF/embedding as Android."""
import ctypes as c
import json
import math
import os
from pathlib import Path
import threading
import time

from .contract import Audio, Cancelled, digest, memory_bytes, profile, read_json, validate_text
from .rendering import render, settings as rendering_settings

REVISION = "b7ee2e8c7459c3bea99da23e3d178125a7d1713c"
LANGUAGES = {"en-US": 2050, "es-MX": 2054}


class Params(c.Structure):
    _fields_ = [("max_audio_tokens", c.c_int32), ("temperature", c.c_float),
        ("top_p", c.c_float), ("top_k", c.c_int32), ("n_threads", c.c_int32),
        ("print_progress", c.c_int32), ("print_timing", c.c_int32),
        ("repetition_penalty", c.c_float), ("language_id", c.c_int32),
        ("instruction", c.c_char_p), ("speaker", c.c_char_p), ("vocoder_left_context_sec", c.c_float)]


class Result(c.Structure):
    _fields_ = [("audio", c.POINTER(c.c_float)), ("audio_len", c.c_int32),
        ("sample_rate", c.c_int32), ("success", c.c_int32), ("error_msg", c.c_char_p), ("t_total_ms", c.c_int64)]


class Capabilities(c.Structure):
    _fields_ = [(x, c.c_int32) for x in ("loaded", "supports_clone", "named", "instruction", "embedding_dim", "speaker_count", "kind")]


Progress = c.CFUNCTYPE(None, c.c_int, c.c_int, c.c_void_p)


class QwenEngine:
    def __init__(self, library, cache_dir, threads=4):
        if type(threads) is not int or not 1 <= threads <= 16:
            raise ValueError("threads must be 1–16")
        self.library, self.cache_dir, self.threads = Path(library).resolve(), Path(cache_dir), threads
        self._operation, self._pointer_lock = threading.RLock(), threading.Lock()
        self._cancelled = threading.Event()
        self._ctx = None
        self._lib = None
        self._voice = None
        self._loaded = False
        self._disposed = False
        self._limit = False

    def initialize(self):
        with self._operation:
            if self._disposed:
                raise RuntimeError("Engine disposed; create a new instance")
            if self._lib:
                return
            os.environ["QWEN3_TTS_LOW_MEM"] = "1"
            lib = c.CDLL(str(self.library))
            signatures = {
                "init": ([], c.c_void_p), "free": ([c.c_void_p], None),
                "cancel": ([c.c_void_p], None), "reset_cancel": ([c.c_void_p], None),
                "set_cpu_threads": ([c.c_int32], c.c_int32), "set_backend_preference": ([c.c_int32], c.c_int32),
                "load_models_with_name": ([c.c_void_p, c.c_char_p, c.c_char_p], c.c_int32),
                "extract_speaker_embedding": ([c.c_void_p, c.c_char_p, c.c_char_p], c.c_int32),
                "get_model_capabilities": ([c.c_void_p], Capabilities),
                "synthesize_with_speaker_embedding": ([c.c_void_p, c.c_char_p, c.c_char_p, Params], Result),
                "free_result": ([Result], None), "get_last_error": ([c.c_void_p], c.c_void_p),
                "free_string": ([c.c_void_p], None), "set_progress_callback": ([c.c_void_p, Progress, c.c_void_p], None),
            }
            for name, (arguments, result) in signatures.items():
                function = getattr(lib, "qwen3_tts_" + name)
                function.argtypes, function.restype = arguments, result
            self._lib = lib
            with self._pointer_lock:
                self._ctx = lib.qwen3_tts_init()
            if not self._ctx:
                self._lib = None
                raise RuntimeError("Cannot allocate Qwen context")
            lib.qwen3_tts_set_backend_preference(1)
            lib.qwen3_tts_set_cpu_threads(self.threads)
            self._progress = Progress(self._on_progress)
            lib.qwen3_tts_set_progress_callback(self._ctx, self._progress, None)

    def _on_progress(self, count, maximum, _):
        if count >= maximum:
            self._limit = True
            self._lib.qwen3_tts_cancel(self._ctx)

    def _error(self):
        pointer = self._lib.qwen3_tts_get_last_error(self._ctx)
        try:
            return c.string_at(pointer).decode("utf-8", "replace") if pointer else "Qwen failed"
        finally:
            self._lib.qwen3_tts_free_string(pointer)

    def load_model(self, directory):
        with self._operation:
            self.initialize()
            if self._loaded:
                raise RuntimeError("A model is already loaded; dispose before replacing it")
            directory = Path(directory).resolve()
            lock = read_json(Path(__file__).with_name("qwen-models.json"))
            for item in lock["files"]:
                path = directory / item["name"]
                if not path.is_file() or path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
                    raise ValueError(f"Missing or modified model: {item['name']}")
            if not self._lib.qwen3_tts_load_models_with_name(self._ctx, os.fsencode(directory), lock["files"][0]["name"].encode()):
                raise RuntimeError(self._error())
            self._loaded = True

    def load_voice_profile(self, manifest):
        with self._operation:
            if self._disposed or not self._loaded:
                raise RuntimeError("Load a model first")
            voice = profile(manifest, "qwen3-tts-gguf", REVISION)
            rendering_settings(voice.get("rendering"))
            embedding = voice.get("embedding_path")
            if embedding is None:
                reference = voice.get("reference_path")
                if reference is None:
                    raise ValueError("Profile requires an authorized WAV or embedding")
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                embedding = self.cache_dir / (digest(reference) + "-" + REVISION + ".json")
                if not embedding.exists():
                    import uuid
                    temporary = embedding.with_name(str(uuid.uuid4()) + ".json")
                    try:
                        self._lib.qwen3_tts_reset_cancel(self._ctx)
                        if not self._lib.qwen3_tts_extract_speaker_embedding(self._ctx, os.fsencode(reference), os.fsencode(temporary)):
                            raise RuntimeError(self._error())
                        self._validate_embedding(temporary)
                        temporary.replace(embedding)
                    finally:
                        temporary.unlink(missing_ok=True)
            self._validate_embedding(embedding)
            voice["embedding_path"] = embedding
            voice["embedding_sha256"] = digest(embedding)
            self._voice = voice

    def _validate_embedding(self, path):
        values = read_json(path)
        capabilities = self._lib.qwen3_tts_get_model_capabilities(self._ctx)
        if not isinstance(values, list) or len(values) != capabilities.embedding_dim or not all(
            type(x) in (int, float) and math.isfinite(x) for x in values
        ):
            raise ValueError("Invalid speaker embedding or incompatible dimension")

    def synthesize(self, text, language="es-MX", max_audio_tokens=320):
        with self._operation:
            if self._disposed:
                raise RuntimeError("Engine disposed")
            validate_text(text, language, self._voice)
            if digest(self._voice["embedding_path"]) != self._voice["embedding_sha256"]:
                raise ValueError("Loaded speaker embedding changed; reload an intact profile")
            if type(max_audio_tokens) is not int or not 16 <= max_audio_tokens <= 512:
                raise ValueError("max_audio_tokens must be 16–512")
            self._limit = False
            with self._pointer_lock:
                self._cancelled.clear()
                self._lib.qwen3_tts_reset_cancel(self._ctx)
            params = Params(max_audio_tokens, .9, 1.0, 50, self.threads, 0, 0, 1.05, LANGUAGES[language], None, None, 2.0)
            started = time.perf_counter()
            result = self._lib.qwen3_tts_synthesize_with_speaker_embedding(
                self._ctx, text.encode("utf-8"), os.fsencode(self._voice["embedding_path"]), params)
            try:
                if self._cancelled.is_set():
                    raise Cancelled("Synthesis cancelled; partial audio discarded")
                if self._limit:
                    raise RuntimeError("Generation token limit reached; partial audio discarded")
                if not result.success:
                    raise RuntimeError(result.error_msg.decode("utf-8", "replace") if result.error_msg else self._error())
                if not result.audio or not 0 < result.audio_len <= 96000 * 45:
                    raise RuntimeError("Invalid native PCM size")
                pcm = c.string_at(result.audio, result.audio_len * 4)
                audio = Audio(pcm, result.sample_rate, self._voice["id"], (time.perf_counter() - started) * 1000, memory_bytes())
                return render(audio, self._voice.get("rendering"))
            finally:
                self._lib.qwen3_tts_free_result(result)

    def cancel(self):
        with self._pointer_lock:
            self._cancelled.set()
            if self._ctx:
                self._lib.qwen3_tts_cancel(self._ctx)

    def dispose(self):
        self._disposed = True
        self.cancel()
        with self._operation, self._pointer_lock:
            if self._ctx:
                self._lib.qwen3_tts_free(self._ctx)
                self._ctx = None
            self._voice, self._loaded, self._disposed = None, False, True
