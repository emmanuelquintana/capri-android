"""Local-only profile format and PCM contract, shared by both desktop engines."""
from array import array
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import sys
import struct
import wave


class Cancelled(RuntimeError):
    pass


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    if path.stat().st_size > 1024 * 1024:
        raise ValueError("JSON exceeds 1 MiB")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def asset(root, entry):
    if not isinstance(entry, dict) or not isinstance(entry.get("file"), str):
        raise ValueError("Missing asset descriptor")
    relative = Path(entry["file"])
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if relative.is_absolute() or not path.is_relative_to(root) or not path.is_file():
        raise ValueError("Asset must be a regular file inside the profile directory")
    if digest(path) != entry.get("sha256"):
        raise ValueError(f"Asset checksum mismatch: {relative}")
    return path


def validate_reference(path, allow_float=False):
    if not 44 <= Path(path).stat().st_size <= 30 * 1024 * 1024:
        raise ValueError("Invalid reference WAV size")
    if allow_float:
        raw = Path(path).read_bytes()
        if raw[:4] != b"RIFF" or raw[8:12] != b"WAVE":
            raise ValueError("Invalid WAV header")
        end = struct.unpack_from("<I", raw, 4)[0] + 8
        if end > len(raw):
            raise ValueError("Truncated RIFF")
        position, format_info, samples = 12, None, None
        while position + 8 <= end:
            tag, size = struct.unpack_from("<4sI", raw, position)
            start = position + 8
            if start + size > end:
                raise ValueError("Truncated WAV chunk")
            if tag == b"fmt ":
                if size < 16:
                    raise ValueError("Invalid WAV format chunk")
                format_info = struct.unpack_from("<HHIIHH", raw, start)
            elif tag == b"data":
                if samples is not None:
                    raise ValueError("Duplicate WAV data chunk")
                samples = raw[start:start+size]
            position = start + size + size % 2
        if format_info == (3, 1, 24000, 96000, 4, 32):
            if samples is None or not 0 < len(samples) <= 30 * 24000 * 4 or len(samples) % 4:
                raise ValueError("Invalid float32 reference size")
            if not all(math.isfinite(x[0]) and abs(x[0]) <= 1 for x in struct.iter_unpack("<f", samples)):
                raise ValueError("Invalid float32 reference samples")
            return len(samples) / 4 / 24000
    with wave.open(str(path), "rb") as wav:
        if (wav.getnchannels(), wav.getsampwidth(), wav.getframerate(), wav.getcomptype()) != (1, 2, 24000, "NONE"):
            raise ValueError("Use mono PCM16 24 kHz reference audio")
        if not 0 < wav.getnframes() <= 30 * 24000 or len(wav.readframes(wav.getnframes())) != wav.getnframes() * 2:
            raise ValueError("Empty, truncated or longer than 30 second reference")
        return wav.getnframes() / 24000


def profile(path, engine, revision):
    path = Path(path).resolve()
    value = read_json(path)
    if value.get("schema_version") != 1 or value.get("engine") != engine:
        raise ValueError("Incompatible voice profile schema or engine")
    if value.get("model_revision") != revision:
        raise ValueError("Profile belongs to a different base model revision")
    if not isinstance(value.get("id"), str) or not value["id"].strip():
        raise ValueError("Profile needs an identity")
    languages = value.get("languages")
    if not isinstance(languages, list) or not languages or any(x not in {"es-MX", "en-US"} for x in languages):
        raise ValueError("Explicit supported languages are required")
    rights = value.get("authorization", {})
    if rights.get("use") is not True or not isinstance(rights.get("statement"), str) or not rights["statement"].strip():
        raise ValueError("Document permission to use the reference/derived profile before import")
    for key in ("reference", "embedding", "capricore_profile", "adapter", "adapter_config"):
        if key in value:
            value[key + "_path"] = asset(path.parent, value[key])
    if "reference_path" in value:
        duration = validate_reference(value["reference_path"], allow_float=engine == "chatterbox-turbo")
        if engine == "chatterbox-turbo" and duration <= 5:
            raise ValueError("Chatterbox Turbo requires a reference longer than 5 seconds")
    return value


def validate_text(text, language, voice):
    if not isinstance(text, str) or not text.strip() or len(text) > 600 or "\x00" in text:
        raise ValueError("Text must contain 1–600 characters, without NUL; split longer replies explicitly")
    if not voice or language not in voice["languages"]:
        raise ValueError("Load a profile that explicitly supports this language")


@dataclass(frozen=True)
class Audio:
    pcm: bytes  # mono little-endian float32, without a WAV header
    sample_rate: int
    profile_id: str
    generation_ms: float
    process_rss_bytes: int | None = None

    def __post_init__(self):
        if type(self.sample_rate) is not int or not 8000 <= self.sample_rate <= 96000:
            raise ValueError("Invalid sample rate")
        if not self.pcm or len(self.pcm) % 4 or len(self.pcm) > self.sample_rate * 45 * 4:
            raise ValueError("Empty, malformed or excessive PCM")
        samples = self.samples()
        if any(not math.isfinite(x) or abs(x) > 1 for x in samples):
            raise ValueError("Non-finite or out-of-range PCM; audio was not silently normalized")
        if not any(samples):
            raise ValueError("Engine returned silence")

    def samples(self):
        samples = array("f")
        samples.frombytes(self.pcm)
        if sys.byteorder != "little":
            samples.byteswap()
        return samples

    def write_wav(self, path):
        samples = array("h", (round(x * 32767) for x in self.samples()))
        if sys.byteorder != "little":
            samples.byteswap()
        # Refuse to overwrite an earlier audition or user recording.
        with Path(path).open("xb") as output, wave.open(output, "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(self.sample_rate)
            wav.writeframes(samples.tobytes())


def memory_bytes():
    """Current process RSS on Windows/Linux; unavailable is reported as null."""
    if sys.platform == "win32":
        import ctypes as c
        class Counters(c.Structure):
            _fields_ = [("cb", c.c_ulong), ("faults", c.c_ulong)] + [(x, c.c_size_t) for x in
                ("peak", "rss", "peak_pool", "pool", "peak_nonpool", "nonpool", "pagefile", "peak_pagefile")]
        result = Counters()
        result.cb = c.sizeof(result)
        c.windll.kernel32.GetCurrentProcess.restype = c.c_void_p
        if c.windll.psapi.GetProcessMemoryInfo(c.c_void_p(c.windll.kernel32.GetCurrentProcess()), c.byref(result), result.cb):
            return result.rss
    elif sys.platform.startswith("linux"):
        import os
        try:
            return int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
        except (OSError, ValueError, IndexError):
            pass
    return None
