"""Bounded linear playback resampling and ring modulation from the Mobile preset."""
from array import array
import math
import struct
import sys
from .contract import Audio


def settings(value):
    if value is None: return None
    if not isinstance(value, dict): raise ValueError("Invalid voice rendering settings")
    result = {"speed": value.get("speed", 1), "metallic_mix": value.get("metallic_mix", 0), "gain": value.get("gain", 1)}
    for key, low, high in [("speed", 1, 1.2), ("metallic_mix", 0, .35), ("gain", 0, 1)]:
        number = result[key]
        if type(number) not in (int, float) or not math.isfinite(number) or not low <= number <= high:
            raise ValueError("Invalid voice rendering value: " + key)
    return result


def render(audio, configuration):
    options = settings(configuration)
    if options is None: return audio
    speed, wet, gain = options["speed"], options["metallic_mix"], options["gain"]
    if speed == 1 and wet == 0 and gain == 1: return audio
    # Mobile stores controls and intermediate PCM values as float32.
    f32 = lambda number: struct.unpack("<f", struct.pack("<f", number))[0]
    speed, wet, gain = (f32(value) for value in (speed, wet, gain))
    dry_mix = f32(1-wet)
    source, output = audio.samples(), array("f")
    for at in range(max(1, int(f32(len(source)/speed)))):
        position = at * speed
        left = min(int(position), len(source)-1)
        fraction = position-left
        sample = source[left] + f32(source[min(left+1,len(source)-1)]-source[left]) * fraction
        if wet:
            sample *= dry_mix + wet*math.cos(math.tau*85*at/audio.sample_rate)
            sample = sample*.94 + round(sample*2048)/2048*.06
        output.append(max(-1, min(1, f32(sample)))*gain)
    if sys.byteorder != "little": output.byteswap()
    return Audio(output.tobytes(), audio.sample_rate, audio.profile_id, audio.generation_ms, audio.process_rss_bytes)
