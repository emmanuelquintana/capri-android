"""Local script-to-audio studio. No remote service, microphone or application integration."""
import argparse
from array import array
import atexit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import sys
import threading
import time
from urllib.parse import urlsplit
import uuid
import wave

from .contract import Cancelled, profile, read_json
from .qwen import QwenEngine, REVISION as QWEN_REVISION
from .chatterbox import ChatterboxEngine, REVISION as TURBO_REVISION

WEB = Path(__file__).with_name("web")
MAX_SCRIPT = 20000


def split_script(text, max_chars=280):
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_SCRIPT or "\x00" in text:
        raise ValueError("Escribe un guion de 1 a 20.000 caracteres, sin caracteres NUL.")
    pieces = []
    for paragraph in re.split(r"\n\s*\n", text.strip()):
        remaining = " ".join(paragraph.split())
        while len(remaining) > max_chars:
            window = remaining[:max_chars + 1]
            ends = list(re.finditer(r"[.!?…]\s+", window))
            cut = ends[-1].end() if ends else window.rfind(" ")
            if cut < 1:
                raise ValueError(f"Hay una palabra de más de {max_chars} caracteres. Divide ese fragmento del guion.")
            pieces.append(remaining[:cut].strip())
            remaining = remaining[cut:].strip()
        if remaining:
            pieces.append(remaining)
    return pieces


class Studio:
    def __init__(self, sources, profiles, output):
        self.sources = sources
        self.profiles, self.output = Path(profiles), Path(output)
        self.engine, self.active_engine = None, None
        self.lock, self.cancelled = threading.Lock(), threading.Event()
        self.loaded = False
        self.worker = None
        self.job = dict(status="idle", completed=0, total=0, message="Lista para tu próximo guion.")

    def catalog(self):
        result = []
        if self.profiles.is_dir():
            for path in sorted(self.profiles.rglob("profile.json")):
                try:
                    if not path.resolve().is_relative_to(self.profiles.resolve()): continue
                    engine_id = read_json(path).get("engine")
                    if engine_id not in self.sources: continue
                    voice = profile(path, engine_id, self.sources[engine_id]["revision"])
                    result.append(dict(key=path.parent.relative_to(self.profiles).as_posix(), name=voice.get("display_name", voice["id"]), languages=voice["languages"], engine=engine_id))
                except (OSError, ValueError, KeyError, TypeError):
                    continue
        return sorted(result, key=lambda item: ("es-MX" not in item["languages"], item["name"]))

    def snapshot(self):
        with self.lock:
            return dict(self.job)

    def start(self, text, selected, language):
        pieces = split_script(text)
        voices = {item["key"]: item for item in self.catalog()}
        if selected not in voices or language not in voices[selected]["languages"]:
            raise ValueError("Selecciona un perfil autorizado compatible con el idioma.")
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise RuntimeError("Hay una locución en curso. Cancélala o espera a que termine.")
            self.cancelled.clear()
            job_id = uuid.uuid4().hex
            self.job = dict(id=job_id, status="loading", total=len(pieces), completed=0,
                message="Preparando el motor y la voz…", profile=voices[selected]["name"], language=language, engine=voices[selected]["engine"])
            manifest = self.profiles / selected / "profile.json"
            self.worker = threading.Thread(target=self._generate, args=(pieces, manifest, language, job_id, voices[selected]["engine"]), name="capri-updates")
            self.worker.start()
            return job_id

    def _update(self, **values):
        with self.lock:
            self.job.update(values)

    def _check_cancel(self):
        if self.cancelled.is_set():
            raise Cancelled("Locución cancelada. El guion sigue disponible.")

    def _generate(self, pieces, manifest, language, job_id, engine_id):
        temporary = self.output / (job_id + ".part")
        final = self.output / (job_id + ".wav")
        started = time.perf_counter()
        try:
            self.output.mkdir(parents=True, exist_ok=True)
            self._check_cancel()
            if not self.loaded or self.active_engine != engine_id:
                if self.engine is not None: self.engine.dispose()
                source = self.sources[engine_id]
                self.loaded = False
                self.engine = source["factory"]()
                self.engine.initialize()
                self.engine.load_model(source["models"])
                self.loaded = True
                self.active_engine = engine_id
            self._check_cancel()
            self.engine.load_voice_profile(manifest)
            self._check_cancel()
            total_samples, sample_rate = 0, None
            with temporary.open("xb") as output, wave.open(output, "wb") as wav:
                # Keep cancellation/errors from being masked by an uninitialized WAV header.
                wav.setparams((1, 2, 24000, 0, "NONE", "not compressed"))
                for index, text in enumerate(pieces):
                    self._check_cancel()
                    self._update(status="generating", message=f"Leyendo fragmento {index+1} de {len(pieces)}…", current_text=text)
                    audio = self.engine.synthesize(text, language)
                    self._check_cancel()
                    if sample_rate is None:
                        sample_rate = audio.sample_rate
                        wav.setparams((1, 2, sample_rate, 0, "NONE", "not compressed"))
                    if audio.sample_rate != sample_rate:
                        raise RuntimeError("El motor cambió la frecuencia de audio durante el guion.")
                    if index:
                        gap = round(sample_rate * .18)
                        wav.writeframes(b"\0\0" * gap)
                        total_samples += gap
                    samples = array("h", (round(value * 32767) for value in audio.samples()))
                    if sys.byteorder != "little": samples.byteswap()
                    wav.writeframes(samples.tobytes())
                    total_samples += len(samples)
                    self._update(completed=index+1, elapsed_ms=round((time.perf_counter()-started)*1000))
            self._check_cancel()
            temporary.rename(final)
            self._update(status="done", message="Tu locución está lista.", audio=f"/audio/{job_id}.wav",
                duration_seconds=total_samples/sample_rate, sample_rate=sample_rate,
                elapsed_ms=round((time.perf_counter()-started)*1000), current_text="")
        except Cancelled as error:
            self._update(status="cancelled", message=str(error), current_text="")
        except Exception as error:
            self.loaded = False
            self._update(status="error", message=str(error), current_text="")
        finally:
            temporary.unlink(missing_ok=True)

    def cancel(self):
        self.cancelled.set()
        if self.engine is not None: self.engine.cancel()
        with self.lock:
            if self.job["status"] in {"loading", "generating"}:
                self.job.update(status="cancelling", message="Deteniendo la generación…")

    def dispose(self):
        self.cancel()
        if self.worker: self.worker.join()
        if self.engine is not None: self.engine.dispose()


def make_handler(studio, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def _headers(self, status, content_type, length=None, **extra):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; media-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if length is not None: self.send_header("Content-Length", str(length))
            for key, value in extra.items(): self.send_header(key.replace("_", "-"), value)
            self.end_headers()

        def _json(self, value, status=200):
            data = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self._headers(status, "application/json; charset=utf-8", len(data))
            self.wfile.write(data)

        def _host_ok(self):
            return self.headers.get("Host") in {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}

        def do_GET(self):
            if not self._host_ok(): return self._json(dict(error="Invalid local host"), 403)
            route = urlsplit(self.path)
            if route.path == "/favicon.ico":
                self._headers(204, "image/x-icon", 0)
                return
            if route.path == "/api/state":
                return self._json(dict(service="capri-updates-studio", job=studio.snapshot(), profiles=studio.catalog()))
            if route.path.startswith("/audio/"):
                name = route.path.removeprefix("/audio/")
                if not re.fullmatch(r"[a-f0-9]{32}\.wav", name): return self._json(dict(error="Not found"), 404)
                path = studio.output / name
                if not path.is_file(): return self._json(dict(error="Not found"), 404)
                size, start, end = path.stat().st_size, 0, path.stat().st_size-1
                status, extra = 200, dict(Accept_Ranges="bytes")
                if self.headers.get("Range"):
                    match = re.fullmatch(r"bytes=(\d+)-(\d*)", self.headers["Range"])
                    if not match: return self._json(dict(error="Invalid range"), 416)
                    start = int(match[1]); end = min(int(match[2]) if match[2] else end, end)
                    if start > end: return self._json(dict(error="Invalid range"), 416)
                    status, extra["Content_Range"] = 206, f"bytes {start}-{end}/{size}"
                if route.query == "download=1": extra["Content_Disposition"] = 'attachment; filename="capri-update.wav"'
                self._headers(status, "audio/wav", end-start+1, **extra)
                with path.open("rb") as source:
                    source.seek(start)
                    remaining = end-start+1
                    while remaining:
                        block = source.read(min(65536, remaining))
                        if not block: break
                        self.wfile.write(block); remaining -= len(block)
                return
            static = {"/": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                      "/styles.css": ("styles.css", "text/css; charset=utf-8")}
            if route.path not in static: return self._json(dict(error="Not found"), 404)
            filename, mime = static[route.path]
            data = (WEB / filename).read_text(encoding="utf-8").replace("__LOCAL_TOKEN__", token).encode("utf-8")
            self._headers(200, mime, len(data)); self.wfile.write(data)

        def do_POST(self):
            if not self._host_ok() or not secrets.compare_digest(self.headers.get("X-Capri-Token", ""), token):
                return self._json(dict(error="Solicitud local no autorizada. Recarga la página."), 403)
            origin = self.headers.get("Origin")
            if origin and origin not in {f"http://127.0.0.1:{self.server.server_port}", f"http://localhost:{self.server.server_port}"}:
                return self._json(dict(error="Origen no autorizado"), 403)
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 100000: raise ValueError("Solicitud demasiado grande o vacía.")
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict): raise ValueError("Solicitud inválida.")
                if self.path == "/api/generate":
                    identifier = studio.start(data.get("text"), data.get("profile"), data.get("language"))
                    return self._json(dict(id=identifier), 202)
                if self.path == "/api/cancel":
                    studio.cancel()
                    return self._json(dict(ok=True))
                return self._json(dict(error="Not found"), 404)
            except (ValueError, RuntimeError, KeyError, TypeError) as error:
                return self._json(dict(error=str(error)), 400)
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", choices=["qwen", "chatterbox"], default="qwen")
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--chatterbox-models", type=Path, help="Also enable English Turbo profiles in the same studio")
    parser.add_argument("--library", type=Path)
    parser.add_argument("--profiles", type=Path, default=Path(".local/profiles"))
    parser.add_argument("--output", type=Path, default=Path(".local/video-exports"))
    parser.add_argument("--cache", type=Path, default=Path(".local/video-cache"))
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if args.engine == "qwen":
        if not args.library: parser.error("Qwen requires --library")
        sources = {"qwen3-tts-gguf": dict(factory=lambda: QwenEngine(args.library, args.cache), revision=QWEN_REVISION, models=args.models)}
    else:
        sources = {"chatterbox-turbo": dict(factory=ChatterboxEngine, revision=TURBO_REVISION, models=args.models)}
    if args.chatterbox_models:
        sources["chatterbox-turbo"] = dict(factory=ChatterboxEngine, revision=TURBO_REVISION, models=args.chatterbox_models)
    studio = Studio(sources, args.profiles, args.output)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(studio, secrets.token_hex(32)))
    atexit.register(studio.dispose)
    print(f"Capri Updates Studio: http://127.0.0.1:{server.server_port}", flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        server.server_close()
        studio.dispose()


if __name__ == "__main__":
    main()
