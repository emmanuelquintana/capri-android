"""Clip-first desktop routing for hosts that own audio playback."""
from dataclasses import dataclass
from pathlib import Path
import platform
import shutil
import sys
from threading import Event, Lock
from time import perf_counter
from typing import Callable

from .clips import VoiceClipLibrary
from .contract import Cancelled, read_json


def detect_hardware(directory):
    free_memory = None
    if sys.platform == "win32":
        import ctypes as c

        class Memory(c.Structure):
            _fields_ = [("length", c.c_ulong), ("load", c.c_ulong), ("total", c.c_ulonglong),
                        ("available", c.c_ulonglong), ("pagefile", c.c_ulonglong), ("pagefile_available", c.c_ulonglong),
                        ("virtual", c.c_ulonglong), ("virtual_available", c.c_ulonglong), ("reserved", c.c_ulonglong)]

        state = Memory()
        state.length = c.sizeof(state)
        if c.windll.kernel32.GlobalMemoryStatusEx(c.byref(state)):
            free_memory, pressure = state.available, state.load >= 90
    elif sys.platform.startswith("linux"):
        try:
            fields = dict((line.split(":", 1)[0], int(line.split()[1]) * 1024)
                          for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith(("MemAvailable:", "MemTotal:")))
            free_memory, pressure = fields["MemAvailable"], fields["MemAvailable"] < fields["MemTotal"] * 0.1
        except (OSError, ValueError, KeyError):
            pass
    return {"architecture": platform.machine().lower(), "availableMemoryBytes": free_memory,
            "memoryPressure": pressure if free_memory is not None else None,
            "freeDiskBytes": shutil.disk_usage(directory).free, "thermalStatus": None,
            "nvidiaDriverToolPresent": shutil.which("nvidia-smi") is not None}


@dataclass(frozen=True)
class InstalledVoice:
    engine_id: str
    profile: Path
    model: Path
    factory: Callable
    minimum_free_bytes: int
    measured_rtf: float
    audition_rank: int = 0  # An approved deployment must supply a positive rank.
    architectures: tuple[str, ...] = ("amd64", "x86_64")

    @property
    def metadata(self):
        return read_json(self.profile)


class CapriVoiceSDK:
    def __init__(self, voices=(), packs=(), *, directory=".", mode="automatic", auto_unload=True, allow_demo=False):
        if mode not in {"automatic", "light", "balanced", "fidelity", "manual"}:
            raise ValueError("Unknown voice performance mode")
        self.voices = tuple(voices)
        self.libraries = tuple(VoiceClipLibrary(pack) for pack in packs)
        if not allow_demo and any(library.manifest["scope"] == "demo" for library in self.libraries):
            raise ValueError("Demo packs require explicit opt-in")
        self.directory, self.mode, self.auto_unload = Path(directory), mode, auto_unload
        self.language, self.selected, self.clips_enabled = "es-MX", None, True
        self.active = None
        self.engine = None
        self.operation = Lock()
        self.active_lock = Lock()
        self.cancelled = Event()
        self.metrics = {}

    def detect_hardware(self):
        return detect_hardware(self.directory)

    def list_profiles(self):
        return [voice.metadata for voice in self.voices if voice.profile.is_file() and voice.model.is_dir()]

    def list_engines(self):
        return sorted({voice.engine_id for voice in self.voices if voice.profile.is_file() and voice.model.is_dir()})

    def set_language(self, language):
        if language not in {"es-MX", "en-US"}:
            raise ValueError("Unsupported language")
        self.language = language

    def select_engine(self, engine_id, profile_id):
        for voice in self.voices:
            if voice.engine_id == engine_id and voice.metadata["id"] == profile_id:
                self.selected = voice
                self.mode = "manual"
                return
        raise ValueError("Unknown installed engine/profile")

    def set_profile(self, profile_id):
        voice = next((item for item in self.voices if item.metadata["id"] == profile_id), None)
        if voice is None:
            raise ValueError("Unknown installed profile")
        self.select_engine(voice.engine_id, profile_id)

    def recommend_engine(self, language=None):
        language = language or self.language
        hardware = self.detect_hardware()
        if hardware["memoryPressure"]:
            return None
        voices = [voice for voice in self.voices if voice.profile.is_file() and voice.model.is_dir()
                  and (hardware["availableMemoryBytes"] or 0) >= voice.minimum_free_bytes
                  and hardware["architecture"] in voice.architectures and language in voice.metadata["languages"]]
        if self.mode == "manual":
            return self.selected if self.selected in voices else None
        voices = [voice for voice in voices if voice.audition_rank > 0 and voice.measured_rtf > 0]
        if self.mode == "light":
            return min(voices, key=lambda v: (v.minimum_free_bytes, v.measured_rtf, -v.audition_rank), default=None)
        if self.mode == "fidelity":
            return max(voices, key=lambda v: (v.audition_rank, -v.measured_rtf), default=None)
        bound = 1.0 if self.mode == "automatic" else 1.5
        return max((voice for voice in voices if voice.measured_rtf <= bound),
                   key=lambda v: (v.audition_rank, -v.measured_rtf), default=None)

    def speak(self, text, *, event_id=None, emotion="neutral", allowed_variants=(), language=None):
        """Call on a worker. The host plays the returned asset or PCM and owns playback events."""
        if not self.operation.acquire(blocking=False):
            return {"status": "busy"}
        try:
            self.cancelled.clear()
            language = language or self.language
            if self.clips_enabled and event_id:
                for variant in (emotion, *allowed_variants):
                    for library in self.libraries:
                        found = library.find_clip(event_id, language, variant)
                        if found is not None:
                            self.metrics = {"source": "clip", "durationMs": found[0]["durationMs"]}
                            return {"status": "ready", "source": "clip", "clip": found[0], "asset": found[1]}
            voice = self.recommend_engine(language)
            if voice is None:
                return {"status": "unavailable"}
            started = perf_counter()
            if self.active is not voice:
                self._unload()
                with self.active_lock:
                    self.engine = voice.factory()
                self.engine.initialize()
                self.engine.load_model(voice.model)
                self.engine.load_voice_profile(voice.profile)
                self.active = voice
            if self.cancelled.is_set():
                raise Cancelled("Cancelled before synthesis")
            audio = self.engine.synthesize(text, language)
            if self.cancelled.is_set():
                raise Cancelled("Cancelled before playback")
            elapsed = round((perf_counter() - started) * 1000)
            duration = len(audio.pcm) / 4 / audio.sample_rate
            self.metrics = {"source": "tts", "engineId": voice.engine_id, "readyMs": elapsed,
                            "durationMs": round(duration * 1000), "rtf": audio.generation_ms / (duration * 1000),
                            "rssBytes": audio.process_rss_bytes}
            return {"status": "ready", "source": "tts", "audio": audio}
        except Cancelled:
            return {"status": "cancelled"}
        except Exception as error:
            self._unload()
            return {"status": "error", "error": str(error)}
        finally:
            try:
                if self.auto_unload:
                    self._unload()
            finally:
                self.operation.release()

    def stop(self):
        self.cancelled.set()
        with self.active_lock:
            if self.engine is not None:
                self.engine.cancel()

    def get_metrics(self):
        return dict(self.metrics)

    def _unload(self):
        with self.active_lock:
            previous, self.engine, self.active = self.engine, None, None
        if previous is not None:
            previous.dispose()

    def unload(self):
        self.stop()
        with self.operation:
            self._unload()
