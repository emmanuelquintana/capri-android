"""Offline clip packs and exact event lookup. This module never loads a TTS engine."""
import argparse
from collections import Counter
from contextlib import contextmanager
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
from tempfile import TemporaryDirectory
from time import sleep
from zipfile import ZipFile

from .contract import digest, read_json


LANGUAGES = {"es-MX", "en-US"}
TOKEN = re.compile(r"[a-z0-9_]+(?:[.-][a-z0-9_]+)*\Z")
HASH = re.compile(r"[0-9a-f]{64}\Z")
MAX_ARCHIVE = 75 * 1024 * 1024
MAX_CLIP = 1024 * 1024
MAX_MANIFEST = 1024 * 1024


def move_directory(source, target):
    for delay in (0.05, 0.10, 0.20, 0.40, None):
        try:
            source.rename(target)
            return
        except OSError as error:
            if delay is None or getattr(error, "winerror", None) not in (5, 32):
                raise
            sleep(delay)


@contextmanager
def pack_lock(directory, pack_id):
    with (directory / (pack_id + ".lock")).open("a+b") as lock:
        lock.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock, fcntl.LOCK_UN)


def decode_manifest(data, allow_private=False):
    language = data["language"]
    scopes={"demo", "production"}
    if allow_private:
        scopes.update(("private-pilot", "private-production"))
    if (data["schemaVersion"] != 1 or language not in LANGUAGES or data["scope"] not in scopes
            or data["id"] != f'capri-clips-{language}-{data["scope"]}' or not TOKEN.fullmatch(data["version"])):
        raise ValueError("Invalid clip manifest identity")
    if not 1 <= len(data["clips"]) <= 900:
        raise ValueError("Unexpected clip count")
    ids, assets, hashes = set(), set(), set()
    for clip in data["clips"]:
        identifier, category = clip["id"], clip["eventType"]
        if (not TOKEN.fullmatch(identifier) or not TOKEN.fullmatch(category)
                or not TOKEN.fullmatch(clip["eventId"]) or not TOKEN.fullmatch(clip["emotion"])
                or identifier != f'{clip["eventId"]}.{clip["emotion"]}'
                or clip["status"] != ("technical-pass" if data["scope"].startswith("private-") else "approved")
                or (data["scope"].startswith("private-") and not str(clip.get("text","")).strip())
                or clip["language"] != language
                or not HASH.fullmatch(clip["sha256"]) or not 1 <= clip["bytes"] <= MAX_CLIP
                or not 1 <= clip["durationMs"] <= 40000
                or clip["asset"] != f"{language}/{category}/{identifier}.opus"
                or any(stem.casefold().split(".")[0] in {"aux", "con", "nul", "prn", *[f"com{i}" for i in range(10)],
                                                           *[f"lpt{i}" for i in range(10)]}
                       for stem in PurePosixPath(clip["asset"]).parts)
                or identifier in ids or clip["asset"] in assets or clip["sha256"] in hashes):
            raise ValueError(f"Invalid or duplicate clip: {identifier}")
        ids.add(identifier)
        assets.add(clip["asset"])
        hashes.add(clip["sha256"])
    if sum(item["bytes"] for item in data["clips"]) > MAX_ARCHIVE:
        raise ValueError("Uncompressed pack exceeds the byte budget")
    return data


def inspect_archive(zipped, allow_private):
    entries=zipped.infolist()
    inventory={item.filename: item for item in entries}
    if (len(inventory)!=len(entries) or "manifest.json" not in inventory
            or not 0<inventory["manifest.json"].file_size<=MAX_MANIFEST):
        raise ValueError("Missing, oversized or duplicated archive manifest")
    manifest_bytes=zipped.read("manifest.json")
    data=decode_manifest(json.loads(manifest_bytes),allow_private)
    if set(inventory)!={"manifest.json", *(row["asset"] for row in data["clips"])}:
        raise ValueError("Archive contains missing or undeclared files")
    for clip in data["clips"]:
        if inventory[clip["asset"]].file_size!=clip["bytes"]:
            raise ValueError(f"Clip size disagrees with archive: {clip['asset']}")
    return inventory,manifest_bytes,data


def verified_archive(archive, expected_sha256):
    if not HASH.fullmatch(expected_sha256):
        raise ValueError("A trusted SHA-256 is required")
    archive=Path(archive)
    if not 0<archive.stat().st_size<=MAX_ARCHIVE or digest(archive)!=expected_sha256:
        raise ValueError("Archive size or SHA-256 failed validation")
    return archive


def verify_file(root, filename, expected_bytes, sha256):
    path = root / filename
    if (not path.resolve().is_relative_to(root.resolve()) or not path.is_file()
            or path.stat().st_size != expected_bytes or digest(path) != sha256):
        raise ValueError(f"Missing or damaged asset: {filename}")
    return path


class VoiceClipLibrary:
    def __init__(self, directory, allow_private=False):
        self.directory = Path(directory).resolve()
        self.manifest = decode_manifest(read_json(self.directory / "manifest.json"), allow_private)
        self.clips = {(row["eventId"], row["emotion"]): row for row in self.manifest["clips"]}

    def list_clips(self):
        return list(self.clips.values())

    def get_event_variants(self, event_id, language):
        return [row for row in self.clips.values() if row["eventId"] == event_id and row["language"] == language]

    def find_clip(self, event_id, language, emotion, allowed_variants=()):
        if language != self.manifest["language"]:
            return None
        for variant in (emotion, *allowed_variants):
            clip = self.clips.get((event_id, variant))
            if clip is not None:
                return clip, verify_file(self.directory, clip["asset"], clip["bytes"], clip["sha256"])
        return None

    def verify(self):
        for clip in self.clips.values():
            verify_file(self.directory, clip["asset"], clip["bytes"], clip["sha256"])
        return self.manifest


class VoicePackManager:
    def __init__(self, directory, allow_private=False):
        self.directory = Path(directory).resolve()
        self.allow_private = allow_private

    def _installed(self, pack_id):
        if (not re.fullmatch(r"capri-clips-(?:es-MX|en-US)-(?:demo|production|private-pilot|private-production)", pack_id)
                or (pack_id.endswith(("-private-pilot","-private-production")) and not self.allow_private)):
            raise ValueError("Invalid pack ID")
        target = self.directory / pack_id
        if target.resolve() != target:
            raise ValueError("Pack directory must not redirect outside its install path")
        return target

    def list_packs(self):
        if not self.directory.exists():
            return []
        return [file.parent.name for file in sorted(self.directory.glob("capri-clips-*/manifest.json"))
                if self.allow_private or not file.parent.name.endswith(("-private-pilot","-private-production"))]

    def verify(self, pack_id):
        return self.open_pack(pack_id).verify()

    def open_pack(self, pack_id):
        return VoiceClipLibrary(self._installed(pack_id), self.allow_private)

    def check_compatibility(self, archive, expected_sha256):
        with ZipFile(verified_archive(archive,expected_sha256)) as zipped:
            _,_,manifest=inspect_archive(zipped,self.allow_private)
        return manifest

    def install(self, archive, expected_sha256, *, replace=False):
        archive=verified_archive(archive,expected_sha256)
        self.directory.mkdir(parents=True, exist_ok=True)
        with TemporaryDirectory(dir=self.directory) as temporary, ZipFile(archive) as zipped:
            stage = Path(temporary) / "new"
            stage.mkdir()
            inventory,manifest_bytes,data=inspect_archive(zipped,self.allow_private)
            (stage / "manifest.json").write_bytes(manifest_bytes)
            target = self._installed(data["id"])
            if target.exists() and not replace:
                raise FileExistsError(f"Pack already installed: {data['id']}")
            for clip in data["clips"]:
                entry = inventory[clip["asset"]]
                path = stage / entry.filename
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as output:
                    output.write(zipped.read(entry))
                verify_file(stage, clip["asset"], clip["bytes"], clip["sha256"])
            with pack_lock(self.directory,data["id"]):
                if not target.exists():
                    move_directory(stage,target)
                elif not replace:
                    raise FileExistsError(f"Pack already installed: {data['id']}")
                else:
                    backup = self.directory / (data["id"] + ".backup")
                    # Keep the backup outside staging so a failed rollback preserves the old pack.
                    move_directory(target,backup)
                    try:
                        move_directory(stage,target)
                    except OSError:
                        move_directory(backup,target)
                        raise
                    shutil.rmtree(backup)
        return data

    def repair(self, archive, expected_sha256):
        return self.install(archive, expected_sha256, replace=True)

    def uninstall(self, pack_id):
        target=self._installed(pack_id)
        with pack_lock(self.directory,pack_id):
            shutil.rmtree(target)


def summary(manifest):
    clips = manifest["clips"]
    return {"id": manifest["id"], "version": manifest["version"], "language": manifest["language"],
            "scope": manifest["scope"], "clips": len(clips), "durationMs": sum(row["durationMs"] for row in clips),
            "audioBytes": sum(row["bytes"] for row in clips), "byEmotion": dict(Counter(row["emotion"] for row in clips)),
            "byCategory": dict(Counter(row["eventType"] for row in clips))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    actions = parser.add_subparsers(dest="action", required=True)
    actions.add_parser("list")
    for name in ("verify", "uninstall"):
        actions.add_parser(name).add_argument("id")
    for name in ("install", "repair"):
        action = actions.add_parser(name)
        action.add_argument("archive", type=Path)
        action.add_argument("sha256")
    options = parser.parse_args()
    manager = VoicePackManager(options.root)
    if options.action in {"install", "repair"}:
        result = summary(getattr(manager, options.action)(options.archive, options.sha256))
    elif options.action == "verify":
        result = summary(manager.verify(options.id))
    elif options.action == "list":
        result = manager.list_packs()
    else:
        manager.uninstall(options.id)
        return
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
