# Integrar CapriCyberVoiceFX

Kit privado, independiente de Capri Android, PC y Studio. Lee [presets.json](presets.json). Mantén OFF como preferencia inicial. Si una locución ya se horneó con DSP en producción, conserva el origen como fallback y no proceses el clip una segunda vez al reproducirlo. STRONG es solo diagnóstico y sus WAV quedaron excluidos tras el filtro técnico. Los derechos registrados cubren el piloto privado. [Autorización](AUTHORIZATION.md)

## Contrato

Usa el [encabezado C](src/capri_cyber_voice_fx.h). Formato float32 normalizado, mono o estéreo interleaved entre 16 y 96 kHz. Crea un contexto por locución o flujo, procesa en sitio o con buffers separados y conserva el contexto entre bloques. La llamada de proceso recibe frames y no asigna. Restablece el contexto al cambiar de locución para evitar memoria residual. Selecciona preset e intensidad antes de cada frase. Si la biblioteca falla o el formato no es compatible, usa el PCM seco.

- **PC y Studio:** [CapriCyberVoiceFX.dll](bin/windows-x64/CapriCyberVoiceFX.dll) y .lib se pueden cargar por ABI C o mediante el enlace ctypes de [batch.py](src/batch.py). El punto natural del sidecar V7 queda después de `model.synthesize` en `core/worker.py`, antes del mezclador o de escribir el WAV. El preset se aplica solo al PCM de salida.
- **Android:** coloca [libCapriCyberVoiceFX.so](bin/android-arm64/libCapriCyberVoiceFX.so) en `jniLibs/arm64-v8a` y usa [CapriCyberVoiceFX.java](src/android/CapriCyberVoiceFX.java). Copia FloatArray del SDK a un ByteBuffer directo, writable y native-order, preasignado en el worker. Procesa los frames a partir de la posición de lectura antes de enviarlos a AudioTrack con PCM float. El adaptador no avanza la posición. Libera el contexto en el mismo worker. En R8 conserva `io.github.emmanuelquintana.voicefx.CapriCyberVoiceFX` y sus métodos JNI.
- **Lote:** `python src/batch.py wav-original/error.error.neutral.wav --out carpeta-nueva --preset SIGNATURE --match-rms`. Acepta varios WAV y un override de `--intensity`. El lote evita la sobreescritura. El comparador usa además compensación constante de LUFS, reproducible en `src/evaluate.py`. El flujo de inferencia no necesita Python para el DSP nativo.

## Reproducir

    ./build-local.ps1 -Parity
    python src/evaluate.py --repo RUTA_REPO --speaker RUTA_TITANET
    python src/asr_check.py --asr RUTA_WHISPER_SMALL
    python src/screen_matched.py
    python tests/test_dsp.py -v
    python tests/test_dsp.py --benchmark
    python src/review.py
    python src/package.py

El build usa herramientas Visual Studio, Java y NDK locales o las rutas que se pasan como argumentos. Las dependencias de evaluación son NumPy, SciPy, librosa, SoundFile, Sherpa ONNX, faster-whisper y FFmpeg. Las etapas se ejecutaron en procesos separados con BLAS/OMP limitados a un hilo para que el análisis y ASR no compitieran por memoria comprometida. Los modelos de evaluación se leen del disco, bajo las rutas ya existentes. El DSP y sus adaptadores nativos no las enlazan.
