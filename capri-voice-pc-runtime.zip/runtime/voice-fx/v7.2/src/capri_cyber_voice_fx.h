#ifndef CAPRI_CYBER_VOICE_FX_H
#define CAPRI_CYBER_VOICE_FX_H
#include <stddef.h>
#ifdef _WIN32
#define CAPRI_CYBER_API __declspec(dllexport)
#else
#define CAPRI_CYBER_API __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
extern "C" {
#endif

typedef struct CapriCyberVoiceFX CapriCyberVoiceFX;
enum CapriCyberMode { CAPRI_CYBER_OFF, CAPRI_CYBER_RING, CAPRI_CYBER_VOCODER, CAPRI_CYBER_RESONANCE, CAPRI_CYBER_HYBRID };

/* Interleaved normalized finite float32, mono/stereo, 16–96 kHz.
   intensity is strength of the added layer, not a gain on the dry path.
   For Ring/Hybrid carrierHz must be 40–180 Hz; other modes ignore it.
   Use the same buffer or separate buffers. A context belongs to one stream. */
CAPRI_CYBER_API CapriCyberVoiceFX *capri_cyber_create(int rate, int channels, int mode, float intensity, float carrierHz);
CAPRI_CYBER_API int capri_cyber_process(CapriCyberVoiceFX *, const float *, float *, size_t frames);
CAPRI_CYBER_API void capri_cyber_reset(CapriCyberVoiceFX *);
CAPRI_CYBER_API void capri_cyber_destroy(CapriCyberVoiceFX *);
#ifdef __cplusplus
}
#endif
#endif
