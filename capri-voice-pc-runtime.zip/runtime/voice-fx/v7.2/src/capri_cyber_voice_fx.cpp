#include "capri_cyber_voice_fx.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <new>

constexpr float pi2 = 6.283185307f;
static float unit(float x) { return std::clamp(x, 0.f, 1.f); }

struct Oscillator {
    float x{1}, y{}, c{}, s{};
    void setup(float hz, int rate) {
        c = std::cos(pi2 * hz / rate);
        s = std::sin(pi2 * hz / rate);
    }
    float step() {
        const float a = x*c - y*s;
        const float b = x*s + y*c;
        x = a; y = b;
        return b;
    }
    void renormalize() {
        const float norm = 1.f / std::sqrt(x*x+y*y);
        x *= norm; y *= norm;
    }
};

struct CapriCyberVoiceFX {
    int rate, channels, mode, stride, untilRead, observations{}, pointer{};
    float strength, carrier;
    float bands[5][2]{}, env[4][2]{}, pole[5]{}, envelopeAttack{}, envelopeRelease{};
    float resMemory[2]{}, slowPower{}, highPower{}, target{}, gate{}, activity{};
    float history[128]{};
    float gateAttack{}, gateRelease{}, energyPole{}, localPole{};
    unsigned sample{};
    Oscillator oscillators[4];

    CapriCyberVoiceFX(int rate, int channels, int mode, float strength, float carrier)
        : rate(rate), channels(channels), mode(mode), stride(std::max(1,rate/6000)),
          untilRead(std::max(1,rate/6000)), strength(strength), carrier(carrier) {
        const float cutoffs[] = {300,700,1350,2450,4400};
        for (int k=0;k<5;++k) pole[k] = coefficient(cutoffs[k]);
        envelopeAttack=coefficient(28); envelopeRelease=coefficient(12);
        gateAttack=coefficient(17); gateRelease=coefficient(33);
        energyPole=coefficient(22); localPole=coefficient(110);
        const float centers[] = {503,946,1579,3059};
        for (int k=0;k<4;++k)
            oscillators[k].setup(mode==CAPRI_CYBER_VOCODER ? centers[k] : carrier*(k==0 ? 1.f : 1.51f), rate);
    }

    float coefficient(float hz) const { return 1.f-std::exp(-pi2*hz/rate); }
    float historyAt(int offset) const { return history[(pointer-1-offset)&127]; }

    float periodicity() const {
        const int minLag = std::max(2, rate/(stride*650));
        const int maxLag = std::min(64, rate/(stride*105));
        float best = 0.f;
        constexpr int window = 56;
        for (int lag=minLag;lag<=maxLag;++lag) {
            float ab=0.f, aa=1e-9f, bb=1e-9f;
            for (int i=0;i<window;++i) {
                const float a=historyAt(i), b=historyAt(i+lag);
                ab+=a*b; aa+=a*a; bb+=b*b;
            }
            if (ab>0) best=std::max(best,ab/std::sqrt(aa*bb));
        }
        return best;
    }
};

CapriCyberVoiceFX *capri_cyber_create(int rate,int channels,int mode,float strength,float carrier) {
    const bool usesCarrier=mode==CAPRI_CYBER_RING||mode==CAPRI_CYBER_HYBRID;
    if (rate<16000||rate>96000||channels<1||channels>2||mode<CAPRI_CYBER_OFF||mode>CAPRI_CYBER_HYBRID||
        !std::isfinite(strength)||strength<0||strength>1||
        (usesCarrier&&(!std::isfinite(carrier)||carrier<40||carrier>180)))
        return nullptr;
    return new(std::nothrow) CapriCyberVoiceFX(rate,channels,mode,strength,usesCarrier?carrier:76.f);
}

int capri_cyber_process(CapriCyberVoiceFX *ctx,const float *in,float *out,size_t frames) {
    if (!ctx || (frames && (!in||!out)) || frames>std::numeric_limits<size_t>::max()/8) return -1;
    if (!frames) return 0;
    auto &s=*ctx;
    if (!s.mode||s.strength==0.f) {
        if (in!=out) std::memcpy(out,in,frames*s.channels*sizeof(float));
        return 0;
    }
    for (size_t i=0;i<frames;++i) {
        const size_t pos=i*s.channels;
        // Select the dominant channel for analysis to keep the same gate on both channels.
        const float a=in[pos], b=s.channels==2 ? in[pos+1] : a;
        const int main=std::abs(a)>=std::abs(b)?0:1;
        const float x=main ? b : a;
        for (int k=0;k<5;++k)
            for (int ch=0;ch<s.channels;++ch)
                s.bands[k][ch]+=s.pole[k]*(in[pos+ch]-s.bands[k][ch]);
        const float mid=s.bands[2][main]-s.bands[0][main];
        const float high=x-s.bands[3][main];
        s.slowPower+=s.energyPole*(mid*mid-s.slowPower);
        s.highPower+=s.energyPole*(high*high-s.highPower);
        s.activity+=s.localPole*(std::abs(x)-s.activity);
        if (--s.untilRead==0) {
            s.untilRead=s.stride;
            s.history[s.pointer]=mid;
            s.pointer=(s.pointer+1)&127;
            if (++s.observations==48) {
                s.observations=0;
                s.target=unit((s.periodicity()-.43f)*2.3f);
            }
        }
        const float brightness=s.highPower/(s.slowPower+s.highPower+1e-9f);
        const float desire=s.target*unit((.67f-brightness)*3.2f) * unit((s.activity-.0025f)*110.f);
        s.gate+=(desire-s.gate)*(desire>s.gate?s.gateAttack:s.gateRelease);
        const float mix=s.strength*s.gate*unit((s.activity-.0018f)*175.f);
        float carriers[4]{};
        const int count=s.mode==CAPRI_CYBER_VOCODER?4:2;
        if (s.mode!=CAPRI_CYBER_RESONANCE) {
            for (int k=0;k<count;++k) {
                if ((s.sample&4095)==0) s.oscillators[k].renormalize();
                carriers[k]=s.oscillators[k].step();
            }
        }
        ++s.sample;
        float pair[2]{};
        float peak=1.f;
        for (int ch=0;ch<s.channels;++ch) {
            float layer=0.f;
            const float body=s.bands[4][ch]-s.bands[0][ch];
            if (s.mode==CAPRI_CYBER_RING||s.mode==CAPRI_CYBER_HYBRID)
                layer=body*(1.20f*carriers[0]+.34f*carriers[1]);
            if (s.mode==CAPRI_CYBER_VOCODER) {
                for (int k=0;k<4;++k) {
                    const float band=std::abs(s.bands[k+1][ch]-s.bands[k][ch]);
                    const float diff=band-s.env[k][ch];
                    s.env[k][ch]+=diff*(diff>0?s.envelopeAttack:s.envelopeRelease);
                    layer+=2.25f*s.env[k][ch]*carriers[k];
                }
            }
            if (s.mode==CAPRI_CYBER_RESONANCE||s.mode==CAPRI_CYBER_HYBRID) {
                const float scaled=18.f*body;
                const float shape=scaled/(1.f+std::abs(scaled));
                const float harmonic=body*(1.f-shape*shape);
                const float upper=harmonic-s.resMemory[ch];
                s.resMemory[ch]+=s.pole[2]*(harmonic-s.resMemory[ch]);
                layer+=(s.mode==CAPRI_CYBER_RESONANCE?3.0f:.6f)*upper;
            }
            pair[ch]=in[pos+ch]+mix*layer;
            peak=std::max(peak,std::abs(pair[ch]));
        }
        for (int ch=0;ch<s.channels;++ch) out[pos+ch]=pair[ch]/peak;
    }
    return 0;
}

void capri_cyber_reset(CapriCyberVoiceFX *s) {
    if (s) *s=CapriCyberVoiceFX(s->rate,s->channels,s->mode,s->strength,s->carrier);
}
void capri_cyber_destroy(CapriCyberVoiceFX *s) { delete s; }
