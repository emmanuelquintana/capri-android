"""Offline WAV processing with the same CapriCyberVoiceFX C ABI used by playback."""
import argparse
import ctypes as C
import json
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
MODES = ('off','ring','vocoder','resonance','hybrid')
F32 = C.POINTER(C.c_float)


def load_fx(path):
    lib = C.CDLL(str(path.resolve()))
    lib.capri_cyber_create.argtypes = (C.c_int, C.c_int, C.c_int, C.c_float, C.c_float)
    lib.capri_cyber_create.restype = C.c_void_p
    lib.capri_cyber_process.argtypes = (C.c_void_p, F32, F32, C.c_size_t)
    lib.capri_cyber_process.restype = C.c_int
    lib.capri_cyber_reset.argtypes = (C.c_void_p,)
    lib.capri_cyber_reset.restype = None
    lib.capri_cyber_destroy.argtypes = (C.c_void_p,)
    lib.capri_cyber_destroy.restype = None
    return lib


def pointer(array):
    return array.ctypes.data_as(F32)


def process(lib, audio, rate, mode, intensity, carrier=76., block=512):
    if block < 1:
        raise ValueError('Block size must be positive')
    audio = np.ascontiguousarray(audio, dtype=np.float32)
    if audio.ndim != 2 or not np.isfinite(audio).all() or np.max(np.abs(audio), initial=0) > 1:
        raise ValueError('Expected finite normalized interleaved PCM')
    ctx = lib.capri_cyber_create(rate, audio.shape[1], MODES.index(mode), intensity, carrier)
    if not ctx:
        raise ValueError('Unsupported sample rate, channels or effect parameters')
    result = np.empty_like(audio)
    try:
        for offset in range(0, len(audio), block):
            src = audio[offset:offset + block]
            dst = result[offset:offset + block]
            if lib.capri_cyber_process(ctx, pointer(src), pointer(dst), len(src)):
                raise RuntimeError('CapriCyberVoiceFX failed')
    finally:
        lib.capri_cyber_destroy(ctx)
    return result


def match_rms(dry, wet):
    if not np.any(wet):
        return wet, 0.0
    gain = np.sqrt(np.sum(dry.astype('float64')**2) / np.sum(wet.astype('float64')**2))
    # Prefer preserving headroom to an exact match for material already at full scale.
    gain = min(gain, .9999 / np.max(np.abs(wet)))
    return wet * gain, float(20*np.log10(gain))


def get_presets():
    return json.loads((ROOT/'presets.json').read_text(encoding='utf8'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('inputs', type=Path, nargs='+')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--lib', type=Path, default=ROOT/'bin/windows-x64/CapriCyberVoiceFX.dll')
    parser.add_argument('--preset', choices=list(get_presets()['presets']), default=get_presets()['default'])
    parser.add_argument('--intensity', type=float)
    parser.add_argument('--match-rms', action='store_true')
    args = parser.parse_args()
    preset = get_presets()['presets'][args.preset].copy()
    if args.intensity is not None:
        preset['intensity'] = args.intensity
    lib = load_fx(args.lib)
    args.out.mkdir(parents=True, exist_ok=True)
    for source in args.inputs:
        audio,rate = sf.read(source, dtype='float32', always_2d=True)
        target = args.out/f'{source.stem}.{args.preset.lower()}.wav'
        y = process(lib,audio,rate,**preset)
        if args.match_rms and preset['mode']!='off' and preset['intensity'] > 0:
            y,_ = match_rms(audio,y)
        with target.open('xb') as stream:
            if preset['mode']=='off' or preset['intensity']==0:
                stream.write(source.read_bytes())
            else:
                sf.write(stream,y,rate,format='WAV',subtype='PCM_24',closefd=False)
        print(target)


if __name__ == '__main__':
    main()
