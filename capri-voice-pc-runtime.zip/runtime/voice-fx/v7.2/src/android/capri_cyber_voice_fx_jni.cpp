#include "../capri_cyber_voice_fx.h"
#include <jni.h>
#include <cstdint>

static CapriCyberVoiceFX *fx(jlong p) {
    return reinterpret_cast<CapriCyberVoiceFX *>(static_cast<intptr_t>(p));
}

extern "C" JNIEXPORT jlong JNICALL
Java_io_github_emmanuelquintana_voicefx_CapriCyberVoiceFX_create(
    JNIEnv *, jclass, jint rate, jint channels, jint mode, jfloat strength, jfloat carrier) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(capri_cyber_create(rate, channels, mode, strength, carrier)));
}

extern "C" JNIEXPORT jint JNICALL
Java_io_github_emmanuelquintana_voicefx_CapriCyberVoiceFX_apply(
    JNIEnv *env, jclass, jlong handle, jobject pcm, jint frames, jint channels) {
    if (frames < 0 || channels < 1 || channels > 2) return -1;
    const auto bytes = static_cast<jlong>(frames) * channels * sizeof(float);
    auto *samples = static_cast<float *>(env->GetDirectBufferAddress(pcm));
    if (!samples || reinterpret_cast<uintptr_t>(samples) % alignof(float) ||
        env->GetDirectBufferCapacity(pcm) < bytes) return -1;
    return capri_cyber_process(fx(handle), samples, samples, frames);
}

extern "C" JNIEXPORT void JNICALL
Java_io_github_emmanuelquintana_voicefx_CapriCyberVoiceFX_resetNative(JNIEnv *, jclass, jlong handle) {
    capri_cyber_reset(fx(handle));
}

extern "C" JNIEXPORT void JNICALL
Java_io_github_emmanuelquintana_voicefx_CapriCyberVoiceFX_release(JNIEnv *, jclass, jlong handle) {
    capri_cyber_destroy(fx(handle));
}
